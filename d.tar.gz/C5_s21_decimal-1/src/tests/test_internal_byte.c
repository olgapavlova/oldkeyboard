/**
 * @file test_internal_byte.c
 * @brief Тесты для внутренней библиотеки internal/byte
 */

#include "../internal/byte.h"
#include "../internal/internal.h"
#include "test.h"

#ifndef CK_LVL
#define CK_LVL C_VERBOSE
#endif

/// Шаблон кейса
/*
static[тип][кейс] _in[] = {};
static[тип][кейс] _out[] = {};
START_TEST(_[кейс]) { ck_assert(false); }
END_TEST
// SIMPLE_CASE([кейс])
SIMPLE_LOOP_CASE([кейс])
*/

/******************************/
/* byte_from_str()           */

/// Разобрать начало строки в byte
// TODO Перевести на чтение из файла
static char *byte_from_str_in[] = {
    "11111111111111111111111111000000",
    "11111111111111111111111111111111",
    "010101010101010101010101010101011",
    "0a000000000000001111111100001111",
};
static byte byte_from_str_out[] = {-64, -1, 1431655765, 65295};
START_TEST(_byte_from_str) {
  int norm = byte_from_str_out[_i];
  char *s = byte_from_str_in[_i];
  int outcome = byte_from_str(s);
  ck_assert_int_eq(norm, outcome);
}
END_TEST
SIMPLE_LOOP_CASE(byte_from_str)

/******************************/
/* byte_bit()                 */
/* Получить k-й бит из byte   */
static byte byte_bit_in_b[] = {0, -1, -17, 43252};
static int byte_bit_in_k[] = {3, 24, 1, 2};
static int byte_bit_out[] = {0, 1, 1, 0};
START_TEST(_byte_bit) {
  int norm = byte_bit_out[_i];
  byte b = byte_bit_in_b[_i];
  int k = byte_bit_in_k[_i];
  int outcome = byte_bit(b, k);
  ck_assert_int_eq(outcome, norm);
}
END_TEST
SIMPLE_LOOP_CASE(byte_bit)

/*****************************************/
/* byte_to_str()                         */
/* Получить строковое представление byte */
static byte byte_to_str_in[] = {-64, -1, 1431655765, 65295};
static char *byte_to_str_out[] = {
    "11111111111111111111111111000000",
    "11111111111111111111111111111111",
    "01010101010101010101010101010101",
    "00000000000000001111111100001111",
};
START_TEST(_byte_to_str) {
  char *norm = byte_to_str_out[_i];
  byte b = byte_to_str_in[_i];
  char outcome[BYTE_LEN + 1] = {'\0'};
  byte_to_str(outcome, b);
  ck_assert_str_eq(norm, outcome);
}
END_TEST
SIMPLE_LOOP_CASE(byte_to_str)

/******************************/
/* byte_sign()                */
/* Получить знак из SO-байта  */
static byte byte_sign_in[] = {0x2345, 0xF3820000, 0, 0xF0F0F0F0};
static int byte_sign_out[] = {1, -1, 1, -1};
START_TEST(_byte_sign) {
  byte b = byte_sign_in[_i];
  int norm = byte_sign_out[_i];
  int outcome = byte_sign(b);
  ck_assert_int_eq(norm, outcome);
}
END_TEST
SIMPLE_LOOP_CASE(byte_sign)

/*****************************************/
/* byte_order()                          */
/* Получить порядок в десятичной системе */
static byte byte_order_in[] = {0xF0000, 0x20000, 0x110000, 0x40000};
static int byte_order_out[] = {15, 2, 17, 4};
START_TEST(_byte_order) {
  int norm = byte_order_out[_i];
  byte b = byte_order_in[_i];
  int outcome = byte_order(b);
  ck_assert_int_eq(norm, outcome);
}
END_TEST
SIMPLE_LOOP_CASE(byte_order)

/**********************************/
/* byte_is_so()                   */
/* Проверить, это SO-байт или нет */
static byte byte_is_so_in[] = {0xFF00FFFF, 0xFF0000, 0xFF00F0, 0x40000};
static int byte_is_so_out[] = {-2, -1, -3, 1};
START_TEST(_byte_is_so) {
  int norm = byte_is_so_out[_i];
  byte b = byte_is_so_in[_i];
  int outcome = byte_is_so(b);
  ck_assert_int_eq(norm, outcome);
}
END_TEST
SIMPLE_LOOP_CASE(byte_is_so)

/***************************************/
/* byte_normalize_so()                 */
/* Нормализовать SO-байт (только биты) */
static byte byte_normalize_so_in[] = {0xFF00FFFF, 0xFF0000, 0xFF00F0, 0x40000};
static byte byte_normalize_so_out[] = {0, 0xFF0000, 0xFF0000, 0x40000};
START_TEST(_byte_normalize_so) {
  byte norm = byte_normalize_so_out[_i];
  byte b = byte_normalize_so_in[_i];
  byte_normalize_so(&b);
  ck_assert_int_eq(norm, b);
}
END_TEST
SIMPLE_LOOP_CASE(byte_normalize_so)

/******************************/
/* Наборы кейсов              */

/// Набор кейсов, проверяющих нормальную работу
Suite *create_suite_main() {
  Suite *result = suite_create(" internal/byte : main ");
  create_tcase_byte_from_str(result);
  create_tcase_byte_bit(result);
  create_tcase_byte_to_str(result);
  create_tcase_byte_sign(result);
  create_tcase_byte_order(result);
  create_tcase_byte_is_so(result);
  create_tcase_byte_normalize_so(result);

  return result;
}

/******************************/
/******************************/
/******************************/

/// Собрать все сьюты в одну точку запуска
SRunner *create_srunner() {
  SRunner *result = srunner_create(create_suite_main());
  return result;
}

/// Точка входа в тестирующую программу
int main(int argc, char **argv) {
  SRunner *sr = create_srunner();

  // При запуске можно указывать тестируемый тег
  if (argc > 1) {
    srunner_run_tagged(sr, NULL, NULL, argv[1], NULL, CK_LVL);
  } else {
    srunner_run_all(sr, CK_LVL);
  }

  // Бывает, Valgrind ругается на утечки
  srunner_free(sr);

  // Полезно знать об успехе, если вызываем откуда-то из другого места
  int failed_quantity = srunner_ntests_failed(sr);
  return (failed_quantity == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
