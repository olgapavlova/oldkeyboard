/**
 * @file test_internal_decimal.c
 * @brief Тесты для внутренней библиотеки internal/decimal
 */

#include "../internal/decimal.h"
#include "../internal/internal.h"
#include "test.h"

#ifndef CK_LVL
#define CK_LVL C_VERBOSE
#endif

/******************************/
/* decimal_from_str()           */

/// Разобрать строку в decimal-запись
// TODO Перевести на чтение из файла
static char *decimal_from_str_in = {};
static decimal decimal_from_str_out = {};
START_TEST(_decimal_from_str) {
  char s[1024] =
      "000000000000000000000000000000000000000000000000000000000000000000000000"
      "00000000000000000000000000000000000000000000000000000000";
  decimal d = {{0, 0, 0, 0}};
  decimal ds = decimal_from_str(s);
  N(decimal_from_str_in);
  N(decimal_from_str_out);
  ck_assert(decimal_eq(d, ds));
}
END_TEST
SIMPLE_LOOP_CASE(decimal_from_str)

/******************************/
/* decimal_digit()   */

/// Получить k-ю цифру из decimal
static decimal decimal_digit_in_d[] = {
    {{4, 2, 0, 17}}, {{1, 5, 83, 1}}, {{0, 17, 92, 472}}, {{81, 2, 27, 28}}};
static int decimal_digit_in_k[] = {3, 14, 1, 56};
static int decimal_digit_out[] = {1, 0, 0, 0};
START_TEST(_decimal_digit) {
  decimal d = decimal_digit_in_d[_i];
  int k = decimal_digit_in_k[_i];
  int mm = decimal_digit_out[_i];
  int m = decimal_digit(d, k);
  ck_assert_int_eq(m, mm);
}
END_TEST
SIMPLE_LOOP_CASE(decimal_digit)

/******************************/
/* decimal_to_bcd()           */

/// Превратить decimal в bcd
static decimal decimal_to_bcd_in[] = {};
static bcd decimal_to_bcd_out[] = {};
START_TEST(_decimal_to_bcd) {
  N(decimal_to_bcd_in);
  N(decimal_to_bcd_out);
  ck_assert(false);
}
END_TEST
SIMPLE_LOOP_CASE(decimal_to_bcd)

/******************************/
/* decimal_to_str()           */

/// Получить строковое представление содержательной части
static decimal decimal_to_str_in[] = {
    {{0, 0, 0, 0}},
    {{1, 0, 0, 0}},
    {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF}},
    {{0xA, 0xAB, 0xABC, 0xABCD}}};
static char *decimal_to_str_out[] = {
    "00000000000000000000000000000000000000000000000000000000000000000000000000"
    "0000000000000000000000",
    "00000000000000000000000000000000000000000000000000000000000000000000000000"
    "0000000000000000000001",
    "11111111111111111111111111111111111111111111111111111111111111111111111111"
    "1111111111111111111111",
    "00000000000000000000101010111100000000000000000000000000101010110000000000"
    "0000000000000000001010"};
START_TEST(_decimal_to_str) {
  decimal d = decimal_to_str_in[_i];
  char ds[DECIMAL_LEN + 1] = {'\0'};
  decimal_to_str(ds, d);
  ck_assert_str_eq(ds, decimal_to_str_out[_i]);
}
END_TEST
SIMPLE_LOOP_CASE(decimal_to_str)

/******************************/
/* decimal_to_simple()        */

/// Превратить decimal в simple
static decimal decimal_to_simple_in[] = {};
static simple decimal_to_simple_out[] = {};
START_TEST(_decimal_to_simple) {
  N(decimal_to_simple_in);
  N(decimal_to_simple_out);
  ck_assert(false);
}
END_TEST
SIMPLE_LOOP_CASE(decimal_to_simple)

/******************************/
/* decimal_sign()             */

/// Получить знак числа
// TODO Переписать в цикле
static decimal decimal_sign_in[] = {{{0, 1, 1, 0x2345}},
                                    {{0, 1, 1, 0xF3820000}},
                                    {{0, 1, 1, 0x0}},
                                    {{0, 1, 1, 0xF0F0F0F0}}};
static int decimal_sign_out[] = {1, -1, 1, -1};
START_TEST(_decimal_sign) {
  decimal d = decimal_sign_in[_i];
  int sd = decimal_sign_out[_i];
  int s = decimal_sign(d);
  ck_assert_int_eq(s, sd);
}
END_TEST
SIMPLE_LOOP_CASE(decimal_sign)

/******************************/
/* decimal_order()            */

/// Получить порядок в десятичной системе
static decimal decimal_order_in[] = {{{0, 0, 0, 0xF0000}},
                                     {{0, 0, 0, 0x20000}},
                                     {{0, 0, 0, 0x110000}},
                                     {{0, 0, 0, 0x40000}}};
static int decimal_order_out[] = {15, 2, 17, 4};
START_TEST(_decimal_order) {
  decimal d = decimal_order_in[_i];
  int nn = decimal_order_out[_i];
  int n = decimal_order(d);
  ck_assert_int_eq(n, nn);
}
END_TEST
SIMPLE_LOOP_CASE(decimal_order)

/******************************/
/* decimal_eq()               */

/// Сравнить два decimal-числа
static decimal decimal_eq_in_1[] = {
    {{0, 1, 2, 3}},
    {{0xF, 0xB1, 0xA2, 0x30}},
    {{0, 1, 2, 3}},
    {{0, 1, 2, 4}},
};
static decimal decimal_eq_in_2[] = {
    {{1, 1, 2, 3}},
    {{0xF, 0xB1, 0xA2, 0x30}},
    {{0, 1, 1, 3}},
    {{0, 1, 2, 4}},
};
static int decimal_eq_out[] = {0, 1, 0, 1};
START_TEST(_decimal_eq) {
  int n = decimal_eq(decimal_eq_in_1[_i], decimal_eq_in_2[_i]);
  ck_assert_int_eq(n, decimal_eq_out[_i]);
}
END_TEST
SIMPLE_LOOP_CASE(decimal_eq)

/******************************/
/* decimal_zero_normalize()   */

/// Нормализовать знак и мантиссу нуля
static decimal decimal_zero_normalize_in[] = {};
static decimal decimal_zero_normalize_out[] = {};
START_TEST(_decimal_zero_normalize) {
  N(decimal_zero_normalize_in);
  N(decimal_zero_normalize_out);
  ck_assert(false);
}
END_TEST
SIMPLE_LOOP_CASE(decimal_zero_normalize)

/******************************/
/* Наборы кейсов              */

/// Набор кейсов, проверяющих нормальную работу
Suite *create_suite_main() {
  Suite *result = suite_create("\n  internal/decimal : main ");
  create_tcase_decimal_from_str(result);
  create_tcase_decimal_digit(result);
  create_tcase_decimal_to_bcd(result);
  create_tcase_decimal_to_str(result);
  create_tcase_decimal_to_simple(result);
  create_tcase_decimal_sign(result);
  create_tcase_decimal_order(result);
  create_tcase_decimal_eq(result);
  create_tcase_decimal_zero_normalize(result);

  return result;
}

/******************************/
/******************************/
/******************************/

/// Собрать все сьюты в одну точку запуска
SRunner *create_srunner() {
  SRunner *result = srunner_create(create_suite_main());
  return result;
}

/// Точка входа в тестирующую программу
int main(int argc, char **argv) {
  SRunner *sr = create_srunner();

  // При запуске можно указывать тестируемый тег
  if (argc > 1) {
    srunner_run_tagged(sr, NULL, NULL, argv[1], NULL, CK_LVL);
  } else {
    srunner_run_all(sr, CK_LVL);
  }

  // Бывает, Valgrind ругается на утечки
  srunner_free(sr);

  // Полезно знать об успехе, если вызываем откуда-то из другого места
  int failed_quantity = srunner_ntests_failed(sr);
  return (failed_quantity == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
