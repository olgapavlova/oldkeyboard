/**
 * @file test_from_decimal_to_int.c
 * @brief Тесты для функции s21_from_decimal_to_int()
 */

#include "test.h"

#ifndef CK_LVL
#define CK_LVL C_VERBOSE
#endif

// Шаблон кейса
/*
static * = {};
START_TEST(_*) {
  ck_assert(false);
} END_TEST
SIMPLE_CASE(*)
SIMPLE_LOOP_CASE(*)
*/

// Функция в принципе существует
START_TEST(_exist) {
  s21_decimal src = {0};
  int dst = 0;
  ck_assert_int_eq(0, s21_from_decimal_to_int(src, &dst));
}
END_TEST
SIMPLE_CASE(exist)

// Ноль превращается в ноль
START_TEST(_zero) {
  s21_decimal src = {0};
  int dst = -1;
  s21_from_decimal_to_int(src, &dst);
  ck_assert_int_eq(0, dst);
}
END_TEST
SIMPLE_CASE(zero)

// Единица превращается в единицу
START_TEST(_one) {
  s21_decimal src = {0};
  src.bits[0] = 10;
  int dst = 0;
  s21_from_decimal_to_int(src, &dst);
  ck_assert_int_eq(1, dst);
}
END_TEST
SIMPLE_CASE(one)

/// Создать сьют со всеми входящими в него кейсами
Suite *create_suite_main() {
  Suite *result = suite_create("MAIN");
  create_tcase_exist(result);
  create_tcase_zero(result);
  create_tcase_one(result);
  // дальше столько вызовов, сколько функций create_tcase_* создано выше

  return result;
}

// Сборка всех сьютов в одну точку запуска
SRunner *create_srunner() {
  SRunner *result = srunner_create(create_suite_main());
  // srunner_add_suite(result, create_suite_error());

  return result;
}

int main(int argc, char **argv) {
  SRunner *sr = create_srunner();

  // При запуске можно указывать тестируемый тег
  if (argc > 1) {
    srunner_run_tagged(sr, NULL, NULL, argv[1], NULL, CK_LVL);
  } else {
    srunner_run_all(sr, CK_LVL);
  }

  // Бывает, Valgrind ругается на утечки
  srunner_free(sr);

  // Полезно знать об успехе, если вызываем откуда-то из другого места
  int failed_quantity = srunner_ntests_failed(sr);
  return (failed_quantity == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
