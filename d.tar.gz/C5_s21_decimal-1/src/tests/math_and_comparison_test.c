/**
 * @brief Тесты для математических функций и функций сравнения
 */

#include <check.h>
#include <stdio.h>

#include "../decimal/functions.h"
#include "../helpers/helpers.h"

#define TEST_OK 0
#define FAIL_BIG 1
#define FAIL_SMALL 2
#define FAIL_ZERO_DIVISOR 3

#define ADD 0
#define SUB 1
#define MUL 2
#define DIV 3
#define IS_EQUAL 4
#define IS_NOT_EQUAL 5
#define IS_GREATER 6
#define IS_GREATER_OR_EQUAL 7
#define IS_LESS 8
#define IS_LESS_OR_EQUAL 9

#define TRUE 1
#define FALSE 0

#ifndef CK_LVL
#define CK_LVL CK_NORMAL
#endif

/**
 * @brief функция тестирует операции сравнения
 * @param dec1 первый входной децимал
 * @param dec2 второй входной децимал
 * @param operation параметр, определяющий конкреттную тестируемую функцию
 * @param expected_result ожидаемый результат
 */
void testing_comparison_and_equality(s21_decimal dec1, s21_decimal dec2,
                                     int operation, int expected_result) {
  int result = 0;
  switch (operation) {
    case IS_EQUAL:
      result = s21_is_equal(dec1, dec2);
      break;
    case IS_NOT_EQUAL:
      result = s21_is_not_equal(dec1, dec2);
      break;
    case IS_GREATER:
      result = s21_is_greater(dec1, dec2);
      break;
    case IS_GREATER_OR_EQUAL:
      result = s21_is_greater_or_equal(dec1, dec2);
      break;
    case IS_LESS:
      result = s21_is_less(dec1, dec2);
      break;
    case IS_LESS_OR_EQUAL:
      result = s21_is_less_or_equal(dec1, dec2);
      break;
  }
  ck_assert_int_eq(result, expected_result);
}

/**
 * @brief функция тестирует арифметические операции, ожидая нормальной работы
 * функции
 * @param dec1 первый входной децимал
 * @param dec2 второй входной децимал
 * @param check ожидаемый результат
 * @param operation параметр, определяющий конкреттную тестируемую функцию
 */
void testing_arithmetic(s21_decimal dec1, s21_decimal dec2, s21_decimal check,
                        int operation) {
  s21_decimal result;
  switch (operation) {
    case ADD:
      s21_add(dec1, dec2, &result);
      break;
    case SUB:
      s21_sub(dec1, dec2, &result);
      break;
    case MUL:
      s21_mul(dec1, dec2, &result);
      break;
    case DIV:
      s21_div(dec1, dec2, &result);
      break;
  }
  ck_assert_int_eq(s21_is_equal(result, check), 1);
}

/**
 * @brief функция тестирует сложение, ожидая код ошибки
 * @param dec1 первый входной децимал
 * @param dec2 второй входной децимал
 * @param error_code ожидаемая ошибка
 */
void testing_arithmetic_error(s21_decimal dec1, s21_decimal dec2, int operation,
                              int expected_result) {
  s21_decimal result;
  int code = 0;
  switch (operation) {
    case ADD:
      code = s21_add(dec1, dec2, &result);
      break;
    case SUB:
      code = s21_sub(dec1, dec2, &result);
      break;
    case MUL:
      code = s21_mul(dec1, dec2, &result);
      break;
    case DIV:
      code = s21_div(dec1, dec2, &result);
      break;
  }
  ck_assert_int_eq(code, expected_result);
}

START_TEST(equal1) {
  s21_decimal dec1 = {{0x00000001, 0x0, 0x00000001, 0x0}};
  s21_decimal dec2 = {{0x00000001, 0x0, 0x00000001, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, TRUE);
}

START_TEST(equal2) {
  s21_decimal dec1 = {{0x00000001, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000001, 0x0, 0x0, 0x00010000}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, FALSE);
}

START_TEST(equal3) {
  s21_decimal dec1 = {{0x00000001, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000001, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, FALSE);
}

START_TEST(equal4) {
  s21_decimal dec1 = {{0x00000001, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x00000001, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, FALSE);
}

START_TEST(equal5) {
  s21_decimal dec1 = {{0x00000010, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x00000010, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, TRUE);
}

START_TEST(equal6) {
  s21_decimal dec1 = {{0x00000010, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x00000010, 0x0, 0x0, 0x800F0000}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, FALSE);
}

START_TEST(equal7) {
  s21_decimal dec1 = {{0x00000005, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000032, 0x0, 0x0, 0x00010000}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, TRUE);
}

START_TEST(equal8) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0xA, 0x0, 0x0, 0x10000}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, TRUE);
}

START_TEST(equal9) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0xA0000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, TRUE);
}

START_TEST(equal10) {
  s21_decimal dec1 = {{0x11111111, 0x11111111, 0x11111111, 0x0}};
  s21_decimal dec2 = {{0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0x10000}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, TRUE);
}

START_TEST(equal11) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, TRUE);
}

START_TEST(equal12) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_EQUAL, TRUE);
}

START_TEST(not_equal1) {
  s21_decimal dec1 = {{0x00000001, 0x0, 0x00000001, 0x0}};
  s21_decimal dec2 = {{0x00000001, 0x0, 0x00000001, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, FALSE);
}

START_TEST(not_equal2) {
  s21_decimal dec1 = {{0x00000001, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000001, 0x0, 0x0, 0x00010000}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, TRUE);
}

START_TEST(not_equal3) {
  s21_decimal dec1 = {{0x00000001, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000001, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, TRUE);
}

START_TEST(not_equal4) {
  s21_decimal dec1 = {{0x00000001, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x00000001, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, TRUE);
}

START_TEST(not_equal5) {
  s21_decimal dec1 = {{0x00000010, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x00000010, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, FALSE);
}

START_TEST(not_equal6) {
  s21_decimal dec1 = {{0x00000010, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x00000010, 0x0, 0x0, 0x800F0000}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, TRUE);
}

START_TEST(not_equal7) {
  s21_decimal dec1 = {{0x00000005, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000032, 0x0, 0x0, 0x00010000}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, FALSE);
}

START_TEST(not_equal8) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0xA, 0x0, 0x0, 0x10000}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, FALSE);
}

START_TEST(not_equal9) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0xA0000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, FALSE);
}

START_TEST(not_equal10) {
  s21_decimal dec1 = {{0x11111111, 0x11111111, 0x11111111, 0x0}};
  s21_decimal dec2 = {{0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0x10000}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, FALSE);
}

START_TEST(not_equal11) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, FALSE);
}

START_TEST(not_equal12) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_NOT_EQUAL, FALSE);
}

START_TEST(greater1) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x2, 0x0, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, FALSE);
}

START_TEST(greater2) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x2, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, TRUE);
}

START_TEST(greater3) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x9, 0x0, 0x0, 0x00080000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, TRUE);
}

START_TEST(greater4) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x1, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, TRUE);
}

START_TEST(greater5) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x2, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, TRUE);
}

START_TEST(greater6) {
  s21_decimal dec1 = {{0x0, 0xFFFFFFFF, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0xFFFFFFFF, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, FALSE);
}

START_TEST(greater7) {
  s21_decimal dec1 = {{0x0, 0xFFFFFFFF, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0xFFFFFFFF, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, TRUE);
}

START_TEST(greater8) {
  s21_decimal dec1 = {{0x1, 0xFFFFFFFF, 0x0, 0x00090000}};
  s21_decimal dec2 = {{0x0, 0xFFFFFFFF, 0x0, 0x00080000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, FALSE);
}

START_TEST(greater9) {
  s21_decimal dec1 = {{0x1, 0xFFFFFFFF, 0x0, 0x00090000}};
  s21_decimal dec2 = {{0x0, 0xFFFFFFFF, 0x0, 0x80080000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, TRUE);
}

START_TEST(greater10) {
  s21_decimal dec1 = {{0x1, 0xFFFFFFFF, 0x0, 0x801C0000}};
  s21_decimal dec2 = {{0x0, 0xFFFFFFFF, 0x0, 0x801C0000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, FALSE);
}

START_TEST(greater11) {
  s21_decimal dec1 = {{0x0, 0xFFFFFFFF, 0x0, 0x801C0000}};
  s21_decimal dec2 = {{0x0, 0xFFFFFFFF, 0x0, 0x801C0000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, FALSE);
}

START_TEST(greater12) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, FALSE);
}

START_TEST(greater13) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER, FALSE);
}

START_TEST(greater_or_equal1) {
  s21_decimal dec1 = {{0x00000004, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000028, 0x0, 0x0, 0x00010000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, TRUE);
}

START_TEST(greater_or_equal2) {
  s21_decimal dec1 = {{0xB, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x6E, 0x0, 0x0, 0x10000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, TRUE);
}

START_TEST(greater_or_equal3) {
  s21_decimal dec1 = {{0x0, 0x4, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x8, 0x0, 0x00080000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, TRUE);
}

START_TEST(greater_or_equal4) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x1, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, TRUE);
}

START_TEST(greater_or_equal5) {
  s21_decimal dec1 = {{0x155, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x255, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, TRUE);
}

START_TEST(greater_or_equal6) {
  s21_decimal dec1 = {{0x0, 0xAAAAAAAA, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0xAAAAFFFF, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, FALSE);
}

START_TEST(greater_or_equal7) {
  s21_decimal dec1 = {{0x0, 0xAAAAAAAA, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0xAAAAAAAA, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, TRUE);
}

START_TEST(greater_or_equal8) {
  s21_decimal dec1 = {{0x1, 0xFFFFFFFF, 0xFFFFFFFF, 0x00090000}};
  s21_decimal dec2 = {{0x0, 0xFFFFFFFF, 0xFFFFFFFF, 0x00080000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, FALSE);
}

START_TEST(greater_or_equal9) {
  s21_decimal dec1 = {{0x1, 0xAAAAAAAA, 0x0, 0x00090000}};
  s21_decimal dec2 = {{0x0, 0xAAAAAAAA, 0x0, 0x80080000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, TRUE);
}

START_TEST(greater_or_equal10) {
  s21_decimal dec1 = {{0x1, 0x0, 0xAAAAAAAA, 0x801C0000}};
  s21_decimal dec2 = {{0x0, 0x0, 0xAAAAAAAA, 0x801C0000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, FALSE);
}

START_TEST(greater_or_equal11) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, TRUE);
}

START_TEST(greater_or_equal12) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_GREATER_OR_EQUAL, TRUE);
}

START_TEST(less1) {
  s21_decimal dec1 = {{0x4, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x9, 0x0, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, TRUE);
}

START_TEST(less2) {
  s21_decimal dec1 = {{0x5, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x8, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, FALSE);
}

START_TEST(less3) {
  s21_decimal dec1 = {{0x3, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x4, 0x0, 0x0, 0x00080000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, FALSE);
}

START_TEST(less4) {
  s21_decimal dec1 = {{0x2, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x2, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, FALSE);
}

START_TEST(less5) {
  s21_decimal dec1 = {{0x8, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x9, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, FALSE);
}

START_TEST(less6) {
  s21_decimal dec1 = {{0x0, 0xFFFFFFFF, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0xFFFFFFFF, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, TRUE);
}

START_TEST(less7) {
  s21_decimal dec1 = {{0x0, 0xFFFFFFFF, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0xFFFFFFFF, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, FALSE);
}

START_TEST(less8) {
  s21_decimal dec1 = {{0x1, 0xCCCCCCCC, 0x0, 0x00090000}};
  s21_decimal dec2 = {{0x0, 0xCCCCCCCC, 0x0, 0x00080000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, TRUE);
}

START_TEST(less9) {
  s21_decimal dec1 = {{0x1, 0xCCCCCCCC, 0x0, 0x00090000}};
  s21_decimal dec2 = {{0x0, 0xCCCCCCCC, 0x0, 0x80080000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, FALSE);
}

START_TEST(less10) {
  s21_decimal dec1 = {{0x1, 0xFFFFFFFF, 0x0, 0x801C0000}};
  s21_decimal dec2 = {{0x0, 0xFFFFFFFF, 0x0, 0x801C0000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, TRUE);
}

START_TEST(less11) {
  s21_decimal dec1 = {{0x0, 0xEEEEEEEE, 0x0, 0x801C0000}};
  s21_decimal dec2 = {{0x0, 0xEEEEEEEE, 0x0, 0x801C0000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, FALSE);
}

START_TEST(less12) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, FALSE);
}

START_TEST(less13) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS, FALSE);
}

START_TEST(less_or_equal1) {
  s21_decimal dec1 = {{0x00000003, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x000000FE, 0x0, 0x0, 0x00010000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, TRUE);
}

START_TEST(less_or_equal2) {
  s21_decimal dec1 = {{0xB, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x6E, 0x0, 0x0, 0x10000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, TRUE);
}

START_TEST(less_or_equal3) {
  s21_decimal dec1 = {{0x0, 0x3, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x1, 0x0, 0x00080000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, FALSE);
}

START_TEST(less_or_equal4) {
  s21_decimal dec1 = {{0x4, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x4, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, FALSE);
}

START_TEST(less_or_equal5) {
  s21_decimal dec1 = {{0x1512, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x2553, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, FALSE);
}

START_TEST(less_or_equal6) {
  s21_decimal dec1 = {{0x0, 0xBBBBBBBB, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0xBBBBBBBB, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, TRUE);
}

START_TEST(less_or_equal7) {
  s21_decimal dec1 = {{0x0, 0xBBBBBBBB, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0xBBBBBBBB, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, FALSE);
}

START_TEST(less_or_equal8) {
  s21_decimal dec1 = {{0x1, 0xFFFFFFFF, 0xFFFFFFFF, 0x00090000}};
  s21_decimal dec2 = {{0x0, 0xFFFFFFFF, 0xFFFFFFFF, 0x00080000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, TRUE);
}

START_TEST(less_or_equal9) {
  s21_decimal dec1 = {{0x1, 0xBBBBBBBB, 0x0, 0x00090000}};
  s21_decimal dec2 = {{0x0, 0xBBBBBBBB, 0x0, 0x80080000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, FALSE);
}

START_TEST(less_or_equal10) {
  s21_decimal dec1 = {{0x1, 0x0, 0xBBBBBBBB, 0x801C0000}};
  s21_decimal dec2 = {{0x0, 0x0, 0xBBBBBBBB, 0x801C0000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, TRUE);
}

START_TEST(less_or_equal11) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x80000000}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, TRUE);
}

START_TEST(less_or_equal12) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  testing_comparison_and_equality(dec1, dec2, IS_LESS_OR_EQUAL, TRUE);
}

START_TEST(basic_add1) {
  s21_decimal dec1 = {{0x0, 0x0, 0x00000001, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x00000002, 0x0}};
  s21_decimal check = {{0x0, 0x0, 0x00000003, 0x0}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add2) {
  s21_decimal dec1 = {{0x0, 0x0, 0x00000008, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x00000001, 0x80000000}};
  s21_decimal check = {{0x0, 0x0, 0x00000007, 0x0}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add3) {
  s21_decimal dec1 = {{0x00000001, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000001, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x00000002, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add4) {
  s21_decimal dec1 = {{0x00000001, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000001, 0x0000001, 0x0, 0x0}};
  s21_decimal check = {{0x00000002, 0x00000001, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add5) {
  s21_decimal dec1 = {{0x0, 0x0, 0x00000001, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x00000002, 0x80000000}};
  s21_decimal check = {{0x0, 0x0, 0x00000001, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add6) {
  s21_decimal dec1 = {{0x0, 0x0, 0x00000005, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x00000005, 0x80000000}};
  s21_decimal check = {{0x0, 0x0, 0x0000000, 0x0}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add7) {
  s21_decimal dec1 = {{0x0, 0x0, 0x00000001, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x00000002, 0x80000000}};
  s21_decimal check = {{0x0, 0x0, 0x00000003, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add8) {
  s21_decimal dec1 = {{0x0, 0x0, 0x00000005, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x00000005, 0x00010000}};
  s21_decimal check = {{0x0, 0x0, 0x000000037, 0x00010000}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add9) {
  s21_decimal dec1 = {{0x0, 0x0, 0x00000005, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x00000005, 0x80010000}};
  s21_decimal check = {{0x0, 0x0, 0x00000002D, 0x00010000}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add10) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFE, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x00000001, 0x0}};
  s21_decimal check = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add11) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  s21_decimal dec2 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal check = {{0x0, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add12) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal dec2 = {{0x99999999, 0x99999999, 0x19999999, 0x0}};
  s21_decimal check = {{0x66666666, 0x66666666, 0xE6666666, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add13) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal dec2 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x10000}};
  s21_decimal check = {{0x66666666, 0x66666666, 0xE6666666, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add14) {
  s21_decimal dec1 = {{0x99999999, 0x99999999, 0x19999999, 0x80000000}};
  s21_decimal dec2 = {{0x99999998, 0x99999999, 0x19999999, 0x0}};
  s21_decimal check = {{0x1, 0x0, 0x0, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add15) {
  s21_decimal dec1 = {{0x00000005, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000005, 0x0, 0x0, 0x00050000}};
  s21_decimal check = {{0x7A125, 0x0, 0x0, 0x00050000}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add16) {
  s21_decimal dec1 = {{0x00000005, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000005, 0x0, 0x0, 0x00040000}};
  s21_decimal check = {{0xC355, 0x0, 0x0, 0x00040000}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add17) {
  s21_decimal dec1 = {{0x00000005, 0x0, 0x0, 0x00050000}};
  s21_decimal dec2 = {{0x00000005, 0x0, 0x0, 0x00040000}};
  s21_decimal check = {{0x37, 0x0, 0x0, 0x00050000}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add18) {
  s21_decimal dec1 = {{0x10000001, 0x3E250261, 0x204FCE5E, 0x801C0000}};
  s21_decimal dec2 = {{0x0, 0x55555555, 0x0, 0x0}};
  s21_decimal check = {{0xABF41C00, 0x8EA6B3FD, 0xC6AEA154, 0xA0000}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add19) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x80000000}};
  s21_decimal check = {{0x0, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(basic_add20) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x0, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, ADD);
}

START_TEST(error_add1) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x00000001, 0x0}};
  int error_code = FAIL_BIG;
  testing_arithmetic_error(dec1, dec2, ADD, error_code);
}

START_TEST(error_add2) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  s21_decimal dec2 = {{0x88000001, 0x1F128130, 0x1027E72F, 0x1C0000}};
  int error_code = FAIL_BIG;
  testing_arithmetic_error(dec1, dec2, ADD, error_code);
}

START_TEST(error_add3) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal dec2 = {{0x10000000, 0x0, 0x0, 0x80000000}};
  int error_code = FAIL_SMALL;
  testing_arithmetic_error(dec1, dec2, ADD, error_code);
}

START_TEST(error_add4) {
  s21_decimal dec1 = {{0x11112222, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  int error_code = FAIL_SMALL;
  testing_arithmetic_error(dec1, dec2, ADD, error_code);
}

START_TEST(basic_sub1) {
  s21_decimal dec1 = {{0x0, 0x5, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x4, 0x0, 0x0}};
  s21_decimal check = {{0x0, 0x1, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub2) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x00020000}};
  s21_decimal dec2 = {{0x9, 0x0, 0x0, 0x00020000}};
  s21_decimal check = {{0x9, 0x0, 0x0, 0x80020000}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub3) {
  s21_decimal dec1 = {{0x0, 0x0, 0x3, 0x00030000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x7, 0x00030000}};
  s21_decimal check = {{0x0, 0x0, 0x4, 0x80030000}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub4) {
  s21_decimal dec1 = {{0x0, 0x99, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x99, 0x0, 0x0}};
  s21_decimal check = {{0x0, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub5) {
  s21_decimal dec1 = {{0x0, 0x3, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0x4, 0x0, 0x0}};
  s21_decimal check = {{0x0, 0x7, 0x0, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub6) {
  s21_decimal dec1 = {{0x0, 0x5, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x6, 0x0, 0x80000000}};
  s21_decimal check = {{0x0, 0xB, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub7) {
  s21_decimal dec1 = {{0x0, 0x0, 0x4, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x2, 0x80000000}};
  s21_decimal check = {{0x0, 0x0, 0x6, 0x0}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub8) {
  s21_decimal dec1 = {{0x7, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x2, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x9, 0x0, 0x0, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub9) {
  s21_decimal dec1 = {{0x5, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x5, 0x0, 0x0, 0x00010000}};
  s21_decimal check = {{0x2D, 0x0, 0x0, 0x00010000}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub10) {
  s21_decimal dec1 = {{0x0, 0x5, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x5, 0x0, 0x80010000}};
  s21_decimal check = {{0x0, 0x37, 0x0, 0x00010000}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub11) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0xA, 0x0, 0x0, 0x1C0000}};
  s21_decimal check = {{0xFFFFFF6, 0x3E250261, 0x204FCE5E, 0x1C0000}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub12) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  s21_decimal check = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub13) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80010000}};
  s21_decimal check = {{0xFFFFFFF5, 0xFFFFFFFF, 0xFFFFFFFF, 0x10000}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub14) {
  s21_decimal dec1 = {{0x1, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x1, 0x0, 0x0, 0x80000000}};
  s21_decimal check = {{0x0, 0x0, 0x0, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(basic_sub15) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x0, 0x0, 0x0, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, SUB);
}

START_TEST(error_sub1) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal dec2 = {{0xFFFFFFFF, 0x0, 0x0, 0x0}};
  int error_code = FAIL_SMALL;
  testing_arithmetic_error(dec1, dec2, SUB, error_code);
}

START_TEST(error_sub2) {
  s21_decimal dec1 = {{0xEEEEEEEE, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0xFFFFFFFF, 0xEEEEEEEE, 0x0}};
  int error_code = FAIL_SMALL;
  testing_arithmetic_error(dec1, dec2, SUB, error_code);
}

START_TEST(error_sub3) {
  s21_decimal dec1 = {{0xEEEEEEEE, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  s21_decimal dec2 = {{0x0, 0xFFFFFFFF, 0xEEEEEEEE, 0x80000000}};
  int error_code = FAIL_BIG;
  testing_arithmetic_error(dec1, dec2, SUB, error_code);
}

START_TEST(error_sub4) {
  s21_decimal dec1 = {{0xEEEEEEEE, 0xFFFFFFFF, 0xFFFFFFFF, 0x00020000}};
  s21_decimal dec2 = {{0x0, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  int error_code = FAIL_BIG;
  testing_arithmetic_error(dec1, dec2, SUB, error_code);
}

START_TEST(basic_mul1) {
  s21_decimal dec1 = {{0x2, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x4, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x8, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul2) {
  s21_decimal dec1 = {{0x3, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x2, 0x0, 0x0, 0x80000000}};
  s21_decimal check = {{0x6, 0x0, 0x0, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul3) {
  s21_decimal dec1 = {{0x00000005, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x00000004, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x00000014, 0x0, 0x0, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul4) {
  s21_decimal dec1 = {{0x6, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x3, 0x0, 0x0, 0x80000000}};
  s21_decimal check = {{0x12, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul5) {
  s21_decimal dec1 = {{0x2, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0xA, 0x0, 0x0, 0x00010000}};
  s21_decimal check = {{0x2, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul6) {
  s21_decimal dec1 = {{0x3, 0x0, 0x0, 0x00010000}};
  s21_decimal dec2 = {{0xA, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x3, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul7) {
  s21_decimal dec1 = {{0x4, 0x0, 0x0, 0x00020000}};
  s21_decimal dec2 = {{0xA, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x4, 0x0, 0x0, 0x00010000}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul8) {
  s21_decimal dec1 = {{0x0, 0xFFFFFFFF, 0x0, 0x0}};
  s21_decimal dec2 = {{0x1, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x0, 0xFFFFFFFF, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul9) {
  s21_decimal dec1 = {{0x0, 0xFFFFFFFF, 0x0, 0x0}};
  s21_decimal dec2 = {{0x1, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x0, 0xFFFFFFFF, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul10) {
  s21_decimal dec1 = {{0x0, 0xFFFFFFFF, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x0, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul11) {
  s21_decimal dec1 = {{0x55555555, 0x0, 0x55555555, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x1E0000}};
  s21_decimal check = {{0x0, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul12) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal dec2 = {{0xFFFFFFF, 0x3E250261, 0x204FCE5E, 0x1C0000}};
  s21_decimal check = {{0xFFFFFFF7, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul13) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal dec2 = {{0xFFFFFFF, 0x3E250261, 0x204FCE5E, 0x1C0000}};
  s21_decimal check = {{0xFFFFFFF7, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul14) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal dec2 = {{0xFFFFFFF, 0x3E250261, 0x204FCE5E, 0x801C0000}};
  s21_decimal check = {{0xFFFFFFF7, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul15) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x0, 0x0, 0x0, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(basic_mul16) {
  s21_decimal dec1 = {{0x0, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x80000000}};
  s21_decimal check = {{0x0, 0x0, 0x0, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, MUL);
}

START_TEST(error_mul1) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  int error_code = FAIL_BIG;
  testing_arithmetic_error(dec1, dec2, MUL, error_code);
}

START_TEST(error_mul2) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  s21_decimal dec2 = {{0xFFFFFFFF, 0xFFFFFFFF, 0x0, 0x0}};
  int error_code = FAIL_BIG;
  testing_arithmetic_error(dec1, dec2, MUL, error_code);
}

START_TEST(error_mul3) {
  s21_decimal dec1 = {{0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0x0}};
  s21_decimal dec2 = {{0xAAAAAAAA, 0x0, 0xAAAAAAAA, 0x80150000}};
  int error_code = FAIL_SMALL;
  testing_arithmetic_error(dec1, dec2, MUL, error_code);
}

START_TEST(error_mul4) {
  s21_decimal dec1 = {{0x55555555, 0x55555555, 0x55555555, 0x0}};
  s21_decimal dec2 = {{0xAAAAAAAA, 0x0, 0xAAAAAAAA, 0x80170000}};
  int error_code = FAIL_SMALL;
  testing_arithmetic_error(dec1, dec2, MUL, error_code);
}

START_TEST(basic_div1) {
  s21_decimal dec1 = {{0x0000006, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0000003, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x0000002, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div2) {
  s21_decimal dec1 = {{0x0000009, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x0000003, 0x0, 0x0, 0x80000000}};
  s21_decimal check = {{0x0000003, 0x0, 0x0, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div3) {
  s21_decimal dec1 = {{0x0000008, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0000004, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x0000002, 0x0, 0x0, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div4) {
  s21_decimal dec1 = {{0x0000005, 0x0, 0x0, 0x80000000}};
  s21_decimal dec2 = {{0x0000001, 0x0, 0x0, 0x80000000}};
  s21_decimal check = {{0x0000005, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div5) {
  s21_decimal dec1 = {{0x00000001, 0x0, 0x0, 0x0}};
  s21_decimal dec2 = {{0x00000001, 0x0, 0x0, 0x00010000}};
  s21_decimal check = {{0xA, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div6) {
  s21_decimal dec1 = {{0x0, 0x0, 0xFFFFFFFF, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0xFFFFFFFF, 0x0}};
  s21_decimal check = {{0x00000001, 0x0, 0x0, 0x0}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div7) {
  s21_decimal dec1 = {{0x55555555, 0x55555555, 0x55555555, 0x0}};
  s21_decimal dec2 = {{0x80000000, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0xAAAAAAAB, 0xAAAAAAAA, 0x27BC86AA, 0x00090000}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div8) {
  s21_decimal dec1 = {{0x55555555, 0x55555555, 0x55555555, 0x0}};
  s21_decimal dec2 = {{0x2, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0xAAAAAAAA, 0xAAAAAAAA, 0x2AAAAAAA, 0x0}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div9) {
  s21_decimal dec1 = {{0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal dec2 = {{0x80000000, 0x80000000, 0x80000000, 0x800F0000}};
  s21_decimal check = {{0xA3B5FB3E, 0x3BAA6805, 0x409F9CBC, 0x000D0000}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div10) {
  s21_decimal dec1 = {{0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal dec2 = {{0x1F40, 0x0, 0x0, 0x00030000}};
  s21_decimal check = {{0x0, 0x0, 0x20000000, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div11) {
  s21_decimal dec1 = {{0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  s21_decimal dec2 = {{0xA, 0x0, 0x0, 0x80000000}};
  s21_decimal check = {{0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFF, 0x10000}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div12) {
  s21_decimal dec1 = {{0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  s21_decimal dec2 = {{0xA, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFF, 0x10000}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div13) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x10000}};
  s21_decimal dec2 = {{0x2, 0x0, 0x0, 0x0}};
  s21_decimal check = {{0x0, 0x0, 0x80000000, 0x00010000}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div14) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x10000}};
  s21_decimal dec2 = {{0x1FFFFFFF, 0x7C4A04C2, 0x409F9CBC, 0x1C0000}};
  s21_decimal check = {{0x1, 0x0, 0x80000000, 0x10000}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(basic_div15) {
  s21_decimal dec1 = {{0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  s21_decimal dec2 = {{0x0, 0x1, 0x0, 0x80000000}};
  s21_decimal check = {{0x0, 0x0, 0x1, 0x80000000}};
  testing_arithmetic(dec1, dec2, check, DIV);
}

START_TEST(error_div1) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x0}};
  int error_code = FAIL_ZERO_DIVISOR;
  testing_arithmetic_error(dec1, dec2, DIV, error_code);
}

START_TEST(error_div2) {
  s21_decimal dec1 = {{0x0, 0x1, 0x1, 0x0}};
  s21_decimal dec2 = {{0x0, 0x0, 0x0, 0x80080000}};
  int error_code = FAIL_ZERO_DIVISOR;
  testing_arithmetic_error(dec1, dec2, DIV, error_code);
}

START_TEST(error_div3) {
  s21_decimal dec1 = {{0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  s21_decimal dec2 = {{0x8, 0x0, 0x0, 0x1C0000}};
  int error_code = FAIL_BIG;
  testing_arithmetic_error(dec1, dec2, DIV, error_code);
}

START_TEST(error_div4) {
  s21_decimal dec1 = {{0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFF, 0x0}};
  s21_decimal dec2 = {{0x5, 0x0, 0x0, 0x10000}};
  int error_code = FAIL_BIG;
  testing_arithmetic_error(dec1, dec2, DIV, error_code);
}

START_TEST(error_div5) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80000000}};
  ;
  s21_decimal dec2 = {{0xA, 0x0, 0x0, 0x1C0000}};
  int error_code = FAIL_SMALL;
  testing_arithmetic_error(dec1, dec2, DIV, error_code);
}

START_TEST(error_div6) {
  s21_decimal dec1 = {{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x80010000}};
  s21_decimal dec2 = {{0xA, 0x0, 0x0, 0x1C0000}};
  int error_code = FAIL_SMALL;
  testing_arithmetic_error(dec1, dec2, DIV, error_code);
}

Suite *create_equal_suite(void) {
  Suite *result = suite_create("EQUAL");
  TCase *tc_equal_features = tcase_create("features");

  tcase_add_test(tc_equal_features, equal1);
  tcase_add_test(tc_equal_features, equal2);
  tcase_add_test(tc_equal_features, equal3);
  tcase_add_test(tc_equal_features, equal4);
  tcase_add_test(tc_equal_features, equal5);
  tcase_add_test(tc_equal_features, equal6);
  tcase_add_test(tc_equal_features, equal7);
  tcase_add_test(tc_equal_features, equal8);
  tcase_add_test(tc_equal_features, equal9);
  tcase_add_test(tc_equal_features, equal10);
  tcase_add_test(tc_equal_features, equal11);
  tcase_add_test(tc_equal_features, equal12);

  suite_add_tcase(result, tc_equal_features);

  return result;
}

Suite *create_not_equal_suite(void) {
  Suite *result = suite_create("NOT_EQUAL");
  TCase *tc_not_equal_features = tcase_create("features");

  tcase_add_test(tc_not_equal_features, not_equal1);
  tcase_add_test(tc_not_equal_features, not_equal2);
  tcase_add_test(tc_not_equal_features, not_equal3);
  tcase_add_test(tc_not_equal_features, not_equal4);
  tcase_add_test(tc_not_equal_features, not_equal5);
  tcase_add_test(tc_not_equal_features, not_equal6);
  tcase_add_test(tc_not_equal_features, not_equal7);
  tcase_add_test(tc_not_equal_features, not_equal8);
  tcase_add_test(tc_not_equal_features, not_equal9);
  tcase_add_test(tc_not_equal_features, not_equal10);
  tcase_add_test(tc_not_equal_features, not_equal11);
  tcase_add_test(tc_not_equal_features, not_equal12);

  suite_add_tcase(result, tc_not_equal_features);

  return result;
}

Suite *create_greater_suite(void) {
  Suite *result = suite_create("GREATER");
  TCase *tc_greater_features = tcase_create("features");

  tcase_add_test(tc_greater_features, greater1);
  tcase_add_test(tc_greater_features, greater2);
  tcase_add_test(tc_greater_features, greater3);
  tcase_add_test(tc_greater_features, greater4);
  tcase_add_test(tc_greater_features, greater5);
  tcase_add_test(tc_greater_features, greater6);
  tcase_add_test(tc_greater_features, greater7);
  tcase_add_test(tc_greater_features, greater8);
  tcase_add_test(tc_greater_features, greater9);
  tcase_add_test(tc_greater_features, greater10);
  tcase_add_test(tc_greater_features, greater11);
  tcase_add_test(tc_greater_features, greater12);
  tcase_add_test(tc_greater_features, greater13);

  suite_add_tcase(result, tc_greater_features);

  return result;
}

Suite *create_greater_or_equal_suite(void) {
  Suite *result = suite_create("GREATER_OR_EQUAL");
  TCase *tc_greater_or_equal_features = tcase_create("features");

  tcase_add_test(tc_greater_or_equal_features, greater_or_equal1);
  tcase_add_test(tc_greater_or_equal_features, greater_or_equal2);
  tcase_add_test(tc_greater_or_equal_features, greater_or_equal3);
  tcase_add_test(tc_greater_or_equal_features, greater_or_equal4);
  tcase_add_test(tc_greater_or_equal_features, greater_or_equal5);
  tcase_add_test(tc_greater_or_equal_features, greater_or_equal6);
  tcase_add_test(tc_greater_or_equal_features, greater_or_equal7);
  tcase_add_test(tc_greater_or_equal_features, greater_or_equal8);
  tcase_add_test(tc_greater_or_equal_features, greater_or_equal9);
  tcase_add_test(tc_greater_or_equal_features, greater_or_equal10);
  tcase_add_test(tc_greater_or_equal_features, greater_or_equal11);
  tcase_add_test(tc_greater_or_equal_features, greater_or_equal12);

  suite_add_tcase(result, tc_greater_or_equal_features);

  return result;
}

Suite *create_less_suite(void) {
  Suite *result = suite_create("LESS");
  TCase *tc_less_features = tcase_create("features");

  tcase_add_test(tc_less_features, less1);
  tcase_add_test(tc_less_features, less2);
  tcase_add_test(tc_less_features, less3);
  tcase_add_test(tc_less_features, less4);
  tcase_add_test(tc_less_features, less5);
  tcase_add_test(tc_less_features, less6);
  tcase_add_test(tc_less_features, less7);
  tcase_add_test(tc_less_features, less8);
  tcase_add_test(tc_less_features, less9);
  tcase_add_test(tc_less_features, less10);
  tcase_add_test(tc_less_features, less11);
  tcase_add_test(tc_less_features, less12);
  tcase_add_test(tc_less_features, less13);

  suite_add_tcase(result, tc_less_features);

  return result;
}

Suite *create_less_or_equal_suite(void) {
  Suite *result = suite_create("LESS_OR_EQUAL");
  TCase *tc_less_or_equal_features = tcase_create("features");

  tcase_add_test(tc_less_or_equal_features, less_or_equal1);
  tcase_add_test(tc_less_or_equal_features, less_or_equal2);
  tcase_add_test(tc_less_or_equal_features, less_or_equal3);
  tcase_add_test(tc_less_or_equal_features, less_or_equal4);
  tcase_add_test(tc_less_or_equal_features, less_or_equal5);
  tcase_add_test(tc_less_or_equal_features, less_or_equal6);
  tcase_add_test(tc_less_or_equal_features, less_or_equal7);
  tcase_add_test(tc_less_or_equal_features, less_or_equal8);
  tcase_add_test(tc_less_or_equal_features, less_or_equal9);
  tcase_add_test(tc_less_or_equal_features, less_or_equal10);
  tcase_add_test(tc_less_or_equal_features, less_or_equal11);
  tcase_add_test(tc_less_or_equal_features, less_or_equal12);

  suite_add_tcase(result, tc_less_or_equal_features);

  return result;
}

Suite *create_add_suite(void) {
  Suite *result = suite_create("ADD");
  TCase *tc_add_features = tcase_create("features");
  TCase *tc_add_errors = tcase_create("errors");

  tcase_add_test(tc_add_features, basic_add1);
  tcase_add_test(tc_add_features, basic_add2);
  tcase_add_test(tc_add_features, basic_add3);
  tcase_add_test(tc_add_features, basic_add4);
  tcase_add_test(tc_add_features, basic_add5);
  tcase_add_test(tc_add_features, basic_add6);
  tcase_add_test(tc_add_features, basic_add7);
  tcase_add_test(tc_add_features, basic_add8);
  tcase_add_test(tc_add_features, basic_add9);
  tcase_add_test(tc_add_features, basic_add10);
  tcase_add_test(tc_add_features, basic_add11);
  tcase_add_test(tc_add_features, basic_add12);
  tcase_add_test(tc_add_features, basic_add13);
  tcase_add_test(tc_add_features, basic_add14);
  tcase_add_test(tc_add_features, basic_add15);
  tcase_add_test(tc_add_features, basic_add16);
  tcase_add_test(tc_add_features, basic_add17);
  tcase_add_test(tc_add_features, basic_add18);
  tcase_add_test(tc_add_features, basic_add19);
  tcase_add_test(tc_add_features, basic_add20);

  tcase_add_test(tc_add_errors, error_add1);
  tcase_add_test(tc_add_errors, error_add2);
  tcase_add_test(tc_add_errors, error_add3);
  tcase_add_test(tc_add_errors, error_add4);

  suite_add_tcase(result, tc_add_features);
  suite_add_tcase(result, tc_add_errors);

  return result;
}

Suite *create_sub_suite(void) {
  Suite *result = suite_create("SUB");
  TCase *tc_sub_features = tcase_create("features");
  TCase *tc_sub_errors = tcase_create("errors");

  tcase_add_test(tc_sub_features, basic_sub1);
  tcase_add_test(tc_sub_features, basic_sub2);
  tcase_add_test(tc_sub_features, basic_sub3);
  tcase_add_test(tc_sub_features, basic_sub4);
  tcase_add_test(tc_sub_features, basic_sub5);
  tcase_add_test(tc_sub_features, basic_sub6);
  tcase_add_test(tc_sub_features, basic_sub7);
  tcase_add_test(tc_sub_features, basic_sub8);
  tcase_add_test(tc_sub_features, basic_sub9);
  tcase_add_test(tc_sub_features, basic_sub10);
  tcase_add_test(tc_sub_features, basic_sub11);
  tcase_add_test(tc_sub_features, basic_sub12);
  tcase_add_test(tc_sub_features, basic_sub13);
  tcase_add_test(tc_sub_features, basic_sub14);
  tcase_add_test(tc_sub_features, basic_sub15);

  tcase_add_test(tc_sub_errors, error_sub1);
  tcase_add_test(tc_sub_errors, error_sub2);
  tcase_add_test(tc_sub_errors, error_sub3);
  tcase_add_test(tc_sub_errors, error_sub4);

  suite_add_tcase(result, tc_sub_features);
  suite_add_tcase(result, tc_sub_errors);

  return result;
}

Suite *create_mul_suite(void) {
  Suite *result = suite_create("MUL");
  TCase *tc_mul_features = tcase_create("features");
  TCase *tc_mul_errors = tcase_create("errors");

  tcase_add_test(tc_mul_features, basic_mul1);
  tcase_add_test(tc_mul_features, basic_mul2);
  tcase_add_test(tc_mul_features, basic_mul3);
  tcase_add_test(tc_mul_features, basic_mul4);
  tcase_add_test(tc_mul_features, basic_mul5);
  tcase_add_test(tc_mul_features, basic_mul6);
  tcase_add_test(tc_mul_features, basic_mul7);
  tcase_add_test(tc_mul_features, basic_mul8);
  tcase_add_test(tc_mul_features, basic_mul9);
  tcase_add_test(tc_mul_features, basic_mul10);
  tcase_add_test(tc_mul_features, basic_mul11);
  tcase_add_test(tc_mul_features, basic_mul12);
  tcase_add_test(tc_mul_features, basic_mul13);
  tcase_add_test(tc_mul_features, basic_mul14);
  tcase_add_test(tc_mul_features, basic_mul15);
  tcase_add_test(tc_mul_features, basic_mul16);

  tcase_add_test(tc_mul_errors, error_mul1);
  tcase_add_test(tc_mul_errors, error_mul2);
  tcase_add_test(tc_mul_errors, error_mul3);
  tcase_add_test(tc_mul_errors, error_mul4);

  suite_add_tcase(result, tc_mul_features);
  suite_add_tcase(result, tc_mul_errors);

  return result;
}

Suite *create_div_suite(void) {
  Suite *result = suite_create("DIV");
  TCase *tc_div_features = tcase_create("features");
  TCase *tc_div_errors = tcase_create("errors");

  tcase_add_test(tc_div_features, basic_div1);
  tcase_add_test(tc_div_features, basic_div2);
  tcase_add_test(tc_div_features, basic_div3);
  tcase_add_test(tc_div_features, basic_div4);
  tcase_add_test(tc_div_features, basic_div5);
  tcase_add_test(tc_div_features, basic_div6);
  tcase_add_test(tc_div_features, basic_div7);
  tcase_add_test(tc_div_features, basic_div8);
  tcase_add_test(tc_div_features, basic_div9);
  tcase_add_test(tc_div_features, basic_div10);
  tcase_add_test(tc_div_features, basic_div11);
  tcase_add_test(tc_div_features, basic_div12);
  tcase_add_test(tc_div_features, basic_div13);
  tcase_add_test(tc_div_features, basic_div14);
  tcase_add_test(tc_div_features, basic_div15);

  tcase_add_test(tc_div_errors, error_div1);
  tcase_add_test(tc_div_errors, error_div2);
  tcase_add_test(tc_div_errors, error_div3);
  tcase_add_test(tc_div_errors, error_div4);
  tcase_add_test(tc_div_errors, error_div5);
  tcase_add_test(tc_div_errors, error_div6);

  suite_add_tcase(result, tc_div_features);
  suite_add_tcase(result, tc_div_errors);

  return result;
}

int main(void) {
  SRunner *sr = srunner_create(NULL);

  srunner_add_suite(sr, create_equal_suite());
  srunner_add_suite(sr, create_not_equal_suite());
  srunner_add_suite(sr, create_greater_suite());
  srunner_add_suite(sr, create_greater_or_equal_suite());
  srunner_add_suite(sr, create_less_suite());
  srunner_add_suite(sr, create_less_or_equal_suite());

  srunner_add_suite(sr, create_add_suite());
  srunner_add_suite(sr, create_sub_suite());
  srunner_add_suite(sr, create_mul_suite());
  srunner_add_suite(sr, create_div_suite());

  srunner_run_all(sr, CK_LVL);
  int number_of_errors = srunner_ntests_failed(sr);
  srunner_free(sr);

  return (number_of_errors) ? 1 : 0;
}
