/**
 * @file test_empty.c
 * @brief Пустой запуск системы тестирования
 */

#include "tests.h"
#include "ten.h"

#ifndef CK_LVL
#define CK_LVL CK_VERBOSE
#endif

#define DATA_DIR "data"

// Шаблон простого кейса
/*
START_TEST(_!!!) {

} END_TEST
SIMPLE_CASE(!!!)
*/

// Шаблон циклического кейса
/*
static !!!_in = {}
static !!!_out = {}
START_TEST(_!!!) {
    // что-то зависит от _i
} END_TEST
SIMPLE_LOOP_CASE(!!!, size???)
*/

// Шаблон кейса на внешних данных
/*
FIXTURE_FUNC(!!!)
START_TEST(_!!!) {
  element e = sample_i(&smpl_!!!, _i);
  int a, b = 0;
  sscanf(e.value, smpl_!!!.tmpl, &a, &b);
  ck_assert_int_eq(a, b);
} END_TEST
FIXTURE_CASE(!!!, 2)
*/


/*
   Проверка генерации случайного длинного десятичного числа
   ten_t ten_rand_long(void);
*/

// long     результирующая строка имеет правильную длину
START_TEST(_rand_long) {
    ck_assert_int_eq(1, 2);
} END_TEST
SIMPLE_CASE(rand_long)

// sign     первый знак строки — + или -
START_TEST(_rand_sign) {

    ck_assert(0);
} END_TEST
SIMPLE_CASE(rand_sign)

// digits   остальные знаки строки — цифры
START_TEST(_rand_digits) {

    ck_assert(0);
} END_TEST
SIMPLE_CASE(rand_digits)

// diff     не вся строка состоит из одних и тех же цифр
START_TEST(_rand_diff) {

    ck_assert(0);
} END_TEST
SIMPLE_CASE(rand_diff)






/// Создать сьют со всеми входящими в него кейсами
Suite *create_suite_main() {
  Suite *result = suite_create("MAIN");
  create_tcase_rand_long(result);
  // create_tcase_(result);
  // create_tcase_(result);
  // create_tcase_(result);
  // create_tcase_(result);
  // create_tcase_(result);
  return result;
}

// Сборка всех сьютов в одну точку запуска
SRunner *create_srunner() {
  SRunner *result = srunner_create(create_suite_main());
  return result;
}

// Точка входа
int main(int argc, char **argv) {
  SRunner *sr = create_srunner();
    printf("!(!(!(!(!(\n");
  // При запуске можно указывать тестируемый тег
  if (argc > 1) {
    srunner_run_tagged(sr, NULL, NULL, argv[1], NULL, CK_LVL);
  } else {
    srunner_run_all(sr, CK_LVL);
  }

  // Полезно знать об успехе, если вызываем откуда-то из другого места
  int failed_quantity = srunner_ntests_failed(sr);

  // Бывает, Valgrind ругается на утечки
  srunner_free(sr);

  return (failed_quantity == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
