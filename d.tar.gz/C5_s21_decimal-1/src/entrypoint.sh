#!/bin/sh
set -e

: "${HOST_UID:=1000}"
: "${HOST_GID:=1000}"
: "${HOST_USER:=host}"
: "${HOST_GROUP:=host}"

# Создать группу с нужным GID (BusyBox addgroup поддерживает -g)
if ! getent group "$HOST_GROUP" >/dev/null 2>&1; then
  addgroup -g "$HOST_GID" -S "$HOST_GROUP"
fi

# Создать пользователя с нужным UID и добавить в группу
if ! id -u "$HOST_USER" >/dev/null 2>&1; then
  adduser -u "$HOST_UID" -G "$HOST_GROUP" -S -D -H -s /bin/sh "$HOST_USER"
fi

exec su-exec "$HOST_USER":"$HOST_GROUP" "$@"
