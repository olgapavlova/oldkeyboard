![Static Badge](https://img.shields.io/badge/%D1%82%D0%B5%D1%81%D1%82%D1%8B_%D0%BD%D0%B0_%D1%81%D0%B5%D0%B1%D0%B5-0?style=flat&label=%D1%81%D1%82%D0%B0%D1%82%D1%83%D1%81&labelColor=979736&color=504945)

# Дополнения к <[check.h](https://libcheck.github.io/check/)> — библиотеке тестирования программ на языке C
1. Базовая справка.
1. Шаблоны тестирующего кода.
1. Макросы сборки циклических тестов.
1. Общая схема (mini framework) BDD-разработки.
1. Тестирование на данных из внешних файлов.
1. Приёмы и лайфхаки (справочник).

### Как подключить библиотеку к проекту
Используем git-функциональность «[Подмодули](https://git-scm.com/book/ru/v2/Инструменты-Git-Подмодули)» (Submodules):
```bash
git submodule add [адрес репозитория] [в какую папку проекта класть]
```
<details>
<summary>Детали про использование подмодулей</summary>

После этого весь проект необходимо обновить и закоммитить:
```bash
git add .
git commit -m "smartcheck sumbodule added"
git push
```

Дальше можно откомпилировать и пользоваться как .a-файлом. Makefile и Dockerfile лежат в корне модуля subcheck:
```bash
make smartcheck.a
```

Если есть расхождения в docker-файлах — придётся шаманить руками.
</details>
