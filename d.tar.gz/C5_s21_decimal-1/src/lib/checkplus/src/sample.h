/**
 * @file
 * @brief
 */

#ifndef SAMPLE_H
#define SAMPLE_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/checkplus.h"

#endif
