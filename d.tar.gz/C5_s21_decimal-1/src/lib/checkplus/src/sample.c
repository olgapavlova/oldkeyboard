/**
 * @file
 * @brief
 */

#include "sample.h"

/// Инициировать поле path в наборе данных
static void _init_path(sample_t* s, char* path) {
  if (s->valid) {
    strcpy(s->path, path);
    if (!(s->path[0])) {
      s->valid = false;
    }
  }
}

/// Инициировать поле file в наборе данных
static void _init_file(sample_t* s) {
  if (s->valid) {
    s->file = fopen(s->path, "r");
    if (!s->file) {
      s->valid = false;
    }
  }
}

/// Инициировать поле tmpl в наборе данных
static void _init_tmpl(sample_t* s) {
  if (s->valid) {
    rewind(s->file);
    fscanf(s->file, "%[^\n]\n", s->tmpl);
    if (s->tmpl[0] == '\0') {
      s->valid = false;
    }
  }
}

/// Инициировать поле current в наборе данных
static void _init_current(sample_t* s) {
  if (s->valid) {
    s->current = 1;
  }
}

/// Инициировать набор данных
sample_t sample_init(char* path) {
  sample_t result = {.valid = true};
  _init_path(&result, path);
  _init_file(&result);
  _init_tmpl(&result);
  _init_current(&result);
  return result;
}

/// Разрушить набор данных и освободить ресурсы
void sample_destroy(sample_t* s) {
  fclose(s->file);
}

/// Получить следующий элемент набора
element_t sample_next(sample_t* s) {
  element_t result = {.valid = false};
  if (s->valid) {
    fscanf(s->file, "%[^\n]\n", result.value);
    if (result.value[0]) {
      s->current++;
      result.valid = true;
    }
  }
  return result;
}

/// Посчитать количество элементов набора
int sample_count(sample_t* s) {
  if (s) {
    return -2;
  }
  return -1;
}

/// Сдвинуть курсор в файле на первую строку с данными
static void _cursor_to_start(sample_t* s) {
  if (s->valid) {
    rewind(s->file);
    char tmp[CHECKPLUS_STR] = {'\0'};
    fscanf(s->file, "%[^\n]\n", tmp);
    s->current = 1;
  }
}

/// Получить i-й элемент набора
element_t sample_i(sample_t* s, int i) {
  element_t result = {.valid = false};
  if (s->valid) {
    if (s->current > i) {
      _cursor_to_start(s);
    }
    for (int j = s->current; j <= i; j++) {
      result = sample_next(s);
    }
  }
  return result;
}

/// Отформатировать объект набора в строку для вывода
void sample_stringify(sample_t* s, char* out) {
  sprintf(out,
          "valid:\t\t%d\n"
          "path:\t\t%s\n"
          "tmpl:\t\t%s\n"
          "current:\t%d\n",
          s->valid, s->path, s->tmpl, s->current);
}
