#define TEST_DATA_PATH "data/add.test"
#define TEST_DATA_SIZE 4

int sum(int, int);
