/**
 * @file
 * @brief
 */

#include "test.h"

#include "add.h"

#ifndef CK_LVL
#define CK_LVL CK_VERBOSE
#endif

static sample_t SMPL = {0};

/// Шаблон кейса
START_TEST(_add) {
  element_t e = sample_i(&SMPL, _i);
  int a, b, c = 0;
  sscanf(e.value, SMPL.tmpl, &a, &b, &c);
  ck_assert_int_eq(sum(a, b), c);
}
END_TEST
SIMPLE_LOOP_CASE(add, TEST_DATA_SIZE)

/// Создать сьют со всеми входящими в него кейсами
Suite *create_suite_main() {
  Suite *result = suite_create("MAIN");
  create_tcase_add(result);
  // дальше столько вызовов, сколько функций create_tcase_* создано выше

  return result;
}

/// Собрать все сьюты в одну точку запуска
SRunner *create_srunner() {
  SRunner *result = srunner_create(create_suite_main());
  // srunner_add_suite(result, create_suite_error());

  return result;
}

/// Точка входа в тестирующую программу
int main(int argc, char **argv) {
  SRunner *sr = create_srunner();

  SMPL = sample_init(TEST_DATA_PATH);

  // При запуске можно указывать тестируемый тег
  if (argc > 1) {
    srunner_run_tagged(sr, NULL, NULL, argv[1], NULL, CK_LVL);
  } else {
    srunner_run_all(sr, CK_LVL);
  }

  // Бывает, Valgrind ругается на утечки
  // srunner_free(sr);

  // Полезно знать об успехе, если вызываем откуда-то из другого места
  int failed_quantity = srunner_ntests_failed(sr);
  return (failed_quantity == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
