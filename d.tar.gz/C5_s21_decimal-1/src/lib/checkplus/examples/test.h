/**
 * @file test.h
 * @brief Заголовочный файл для теста
 */

#ifndef TEST_H
#define TEST_H

#include <check.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "../include/smartcheck.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Служебные макросы */
#define _I [_i]
#define STR(s) s
#define CON(a, b) a##b
#define ck_assert_char_eq(a, b) ck_assert_int_eq(a, b)

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Макросы для создания тест-кейсов                        */

// Создать кейс из одного вызова простого теста
#define SIMPLE_CASE(name)                    \
  void create_tcase_##name(Suite *suite) {   \
    TCase *tc = tcase_create(" " #name " "); \
    tcase_set_tags(tc, #name);               \
    tcase_add_test(tc, _##name);             \
    suite_add_tcase(suite, tc);              \
  }

// Создать кейс из циклического вызова простого теста
#define SIMPLE_LOOP_CASE(name, size)               \
  void create_tcase_##name(Suite *suite) {         \
    TCase *tc = tcase_create(" " #name " ");       \
    tcase_set_tags(tc, #name);                     \
    tcase_add_loop_test(tc, _##name, 1, size + 1); \
    suite_add_tcase(suite, tc);                    \
  }

#endif
