/**
 * @file checkplus.h
 * @brief Публичный API библиотеки checkplus
 */

#ifndef CHECKPLUS_INCLUDE_CHECKPLUS_H
#define CHECKPLUS_INCLUDE_CHECKPLUS_H

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "macro.h"

/// Набор данных для тестов
typedef struct _sample {
  bool valid;        /**< флаг неполадок с объектом */
  char path[CHECKPLUS_STR]; /**< путь к файлу (или хранилищу набора данных) */
  FILE *file;        /**< файловый дескриптор */
  char tmpl[CHECKPLUS_STR]; /**< строка шаблона для чтения из файла */
  int current; /**< номер элемента, на который указывает курсор */
} sample_t;

/// Строка с данными для тестирования из набора
typedef struct _element {
  bool valid;         /**< флаг неполадок с объектом */
  char value[CHECKPLUS_STR]; /**< строка из набора */
  int index;          /**< номер строки в наборе */
} element_t;

/// Инициировать набор данных
sample_t sample_init(char *);

/// Разрушить набор данных и освободить ресурсы
void sample_destroy(sample_t *);

/// Получить следующий элемент набора
element_t sample_next(sample_t *);

/// Посчитать количество элементов набора
int sample_count(sample_t *);

/// Получить i-й элемент набора
element_t sample_i(sample_t *, int);

/// Отформатировать объект набора в строку для вывода
void sample_stringify(sample_t *, char *);

#endif
