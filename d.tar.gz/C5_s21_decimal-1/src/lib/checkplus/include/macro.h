/**
 * @file macro.h
 * @brief Типовые макросы для сборки тестов 
 */

#ifndef CHECKPLUS_INCLUDE_MACRO_H
#define CHECKPLUS_INCLUDE_MACRO_H


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Константы */
// Максимальная длина строки, используемой в тестовых целях
#ifndef CHECKPLUS_STR
#define CHECKPLUS_STR 1024
#endif

// Расширение файлов с данными для тестов
#ifndef TEST_DATA_EXT
#define TEST_DATA_EXT "test"
#endif

// Подкаталог с данными для тестов
#ifndef TEST_DATA_DIR
#define TEST_DATA_DIR "data"
#endif


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Служебные макросы */
#define _I [_i]
#define STR(s) #s
#define CON(a, b) a##b
#define ck_assert_char_eq(a, b) ck_assert_int_eq(a, b)

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Макросы для создания тест-кейсов                        */

// Создать кейс из одного вызова простого теста
#define SIMPLE_CASE(name)                      \
  void create_tcase_##name(Suite *suite) {     \
    TCase *tc = tcase_create("\t" #name "\t"); \
    tcase_set_tags(tc, #name);                 \
    tcase_add_test(tc, _##name);               \
    suite_add_tcase(suite, tc);                \
  }

// Создать кейс из циклического вызова простого теста
#define SIMPLE_LOOP_CASE(name, size)           \
  void create_tcase_##name(Suite *suite) {     \
    TCase *tc = tcase_create(" " #name " ");   \
    tcase_set_tags(tc, #name);                 \
    tcase_add_loop_test(tc, _##name, 0, size); \
    suite_add_tcase(suite, tc);                \
  }

// Создать функции вкл/выкл fixture на данных из файла
#define FIXTURE_FUNC(name)                              \
  static sample_t smpl_##name = {0};                    \
  void setup_##name(void) {                             \
    char path[CHECKPLUS_STR + 1] = {'\0'};                           \
    sprintf(path, TEST_DATA_DIR "/%s." TEST_DATA_EXT, STR(name)); \
    smpl_##name = sample_init(path);                    \
  }                                                     \
  void teardown_##name(void) { sample_destroy(&smpl_##name); }

// Создать циклический кейс с фикстурой на данных из файла
#define FIXTURE_CASE(name, size)                                    \
  void create_tcase_##name(Suite *suite) {                          \
    TCase *tc = tcase_create(" " #name " ");                        \
    tcase_set_tags(tc, #name);                                      \
    tcase_add_unchecked_fixture(tc, setup_##name, teardown_##name); \
    tcase_add_loop_test(tc, _##name, 1, size + 1);                  \
    suite_add_tcase(suite, tc);                                     \
  }

#endif
