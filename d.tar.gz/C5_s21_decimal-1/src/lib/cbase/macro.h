/**
 * @file macro.h
 * @brief Прочие полезные макросы
 */

#ifndef MACRO_H
#define MACRO_H

#include <stdio.h>
#include <stdlib.h>

/// Псевдоиспользование переменной
#define N(s)            \
  do {                  \
    if ((&s) == NULL) { \
    }                   \
  } while (0);

#endif
