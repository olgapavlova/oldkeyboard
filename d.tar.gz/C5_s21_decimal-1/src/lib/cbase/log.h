/**
 * @file log.h
 * @brief Макросы для логирования
 */

#ifndef LOG_H
#define LOG_H

#ifndef LOGLEVEL
#define LOGLEVEL 0
#endif

#ifndef LOGDEF
#define LOGDEF 0
#endif

// Лог-строка для произвольной переменной
#define L(tmpl, var)                                                   \
  do {                                                                 \
    if (LOGLEVEL) {                                                    \
      fprintf(stderr, "%s:%d\t%s()\t" #var ": %" #tmpl "\n", __FILE__, \
              __LINE__, __func__, (var));                              \
    }                                                                  \
  } while (0);

// Типизированные лог-строки
#define Ls(var) L(s, var)
#define Li(var) L(d, var)

// Строка описания функции
#define LD(text)                      \
  do {                                \
    if (LOGDEF) {                     \
      fprintf(stderr, "%s\n", #text); \
    }                                 \
  } while (0);

#endif
