/**
 * @file ten.h
 * @brief Декларации для работы с десятичной записью
 */

#ifndef TEN_H
#define TEN_H

#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include "cbase/macro.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// TODO Синхронизировать с общим списком констант

/// Базовые константы (для короткой версии числа)
#define TEN_MANTISS 29  // Длина мантиссы в десятичной записи
#define TEN_EXP 28      // Максимальная экспонента

/// Производные константы для работы с длинными числами
#define TEN_MANTISS_LONG TEN_MANTISS * 2 + 1
#define TEN_EXP_LONG TEN_EXP * 2 + 1
#define TEN_STR (TEN_MANTISS_LONG + TEN_EXP_LONG) * 2 + 1

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/// Псевдоним типа для статуса флага
typedef enum { FLAG_NO = -1, FLAG_UNDEF, FLAG_YES } flag_t;

/// Псевдоним типа для знака числа
typedef enum { SIGN_MINUS = -1, SIGN_ZERO, SIGN_PLUS } sign_t;

/// Псевдоним типа для результата сравнения
typedef enum {
  COMPARE_ERROR = -2,
  COMPARE_LESS,
  COMPARE_EQ,
  COMPARE_MORE
} compare_t;

/// Псевдоним типа для результата выполнения функции (OK или ошибка)
typedef enum { RESULT_OK = 0, RESULT_FAIL } result_t;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/// Псевдоним типа для работы с десятичной записью
typedef struct _ten_t {
  flag_t valid;  //<! верно ли число по совокупности требований
  flag_t normalized;  //<! провели ли мы нормализацию
  flag_t lng;         //<! оказалось ли число длинным

  sign_t sign;  //<! знак числа
  int exp;      //<! показатель степени числа
  char mantiss[TEN_MANTISS_LONG + 1];  //<! мантисса числа

  char str[TEN_STR + 1];  //<! строка "знак + цифры + \0"
} ten_t;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/// Обновить все поля числа (например, после операции)
void ten_update(ten_t *);

/// Проверить число на соответствие требованиям
void ten_check_valid(ten_t *);

/// Нормализовать число
void ten_normalize(ten_t *);

/// Проверить, длинное ли число
void ten_check_lng(ten_t *);

/// Собрать строковое представление числа
void ten_set_str(ten_t *);

/// Получить целую часть (до запятой) в виде строки
result_t ten_get_truncate(ten_t *, char *);

/// Получить дробную часть (после запятой) в виде строки
result_t ten_get_fraction(ten_t *, char *);

/// Получить десятичную запись из float
ten_t ten_from_float(float);

/// Получить десятичную запись из целого
ten_t ten_from_int(int);

/// Получить десятичную запись из строки
ten_t ten_from_str(char *);

/// Сравнить два десятичных
compare_t ten_compare(ten_t *, ten_t *);

/// Обрезать до короткого значения (если возможно)
result_t ten_shortify(ten_t *);

/// Отбросить дробную часть десятичного
result_t ten_truncate(ten_t *);

/// Округлить вниз
result_t ten_floor(ten_t *);

/// Округлить по-банковски
result_t ten_round(ten_t *);

/// Сгенерить случайное короткое десятичное число
ten_t ten_rand_short(void);

/// Сгенерить случайное длинное десятичное число
ten_t ten_rand_long(void);

#endif
