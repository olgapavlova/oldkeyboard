/**
 * @file constant.h
 * @brief Определения констант модуля
 */

#ifndef NUMS_CONSTANT_H
#define NUMS_CONSTANT_H

#define BIT_LEN 32        // длина блока бит
#define BYTE_LEN BIT_LEN  // длина байта
#define BIT_Q 3           // количество блоков

#define DECIMAL_LEN BIT_LEN * BIT_Q  // сколько цифр в двоичном числе
#define BCD_DIGIT_LEN 4              // сколько бит в бинарной записи BCD-цифры
#define BCD_LEN DECIMAL_LEN          // сколько цифр в BCD-числе (с избытком)

#define FIRST_DIGIT_MAP 0x1  // выявление первой цифры
#define ORDER_SHIFT 0x10     // сдвиг кода порядка
#define ORDER_MAP 0x1F       // выявление кода порядка после сдвига
#define EMPTY_SO_MAP \
  0xFF00FFFF  // выявление не разрешённых к заполнению битов в SO-байте

#endif
