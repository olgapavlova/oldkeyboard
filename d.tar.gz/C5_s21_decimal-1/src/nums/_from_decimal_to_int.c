#include <stdbool.h>
#include <stdlib.h>

#include "../tests/macro.h"
#include "functions.h"

#define MAX_DIGITS 32 * 3
#define BCD_SET_SIZE 4

#define EOK 0
#define EBIG 1
#define ESMALL 2
#define EDIV 3

/// BCD-запись числа
typedef struct s21_bcd {
  int digits[MAX_DIGITS];  // TODO Оптимизировать размер типа?
  int sign_and_mantissa;
} s21_bcd;

s21_bcd _decimal_to_bcd(s21_decimal);
int _bcd_to_int(s21_bcd);

/// Конвертировать из decimal в int
/// Возвращаемое значение — результат (0, если ОК)
int s21_from_decimal_to_int(s21_decimal src, int *dst) {
  int result = EOK;

  // Превращаем бинарную запись в BCD-запись
  s21_bcd src_bcd = _decimal_to_bcd(src);

  // Конвертим BCD в целое число
  *dst = _bcd_to_int(src_bcd);

  return result;
}

int _get_dec_digit(s21_decimal dec, int n) {
  if (n > MAX_BIN_DIGITS) {
    exit(1);
  }  // TODO Обработка ошибки
  int part = n / 32;  // TODO Магическое значение
  int result = (dec.bits[part] >> (n % 32)) && 1;

  return result;
}

s21_bcd _decimal_to_bcd(s21_decimal dec) {
  s21_bcd result = {0};

  // Цикл по количеству знаков в двоичной записи decimal
  for (int i = 0; i < MAX_BIN_DIGITS; i++) {
    for (int d = 0; d < MAX_BCD_DIGITS; d += BCD_SET_SIZE) {
      // Берём очередную тетраду
      int digit = 0;
      for (int j = 0; j < BCD_SET_SIZE; j++) {
        digit += (result.digits[d + j] << j);
      }

      // Если > 4 — прибавляем 3
      digit += (digit > 4) ? 3 : 0;

      // Сдвигаем всё влево
      digit = digit << 1;

      // Проверяем, есть ли перенос -- куда его?
      // int transfer = (digit >> 4) && 1;

      // Конвертим обратно в BCD
      for (int j = 0; j < BCD_SET_SIZE; j++) {
        result.digits[d + j] = (digit >> j) && 1;
      }
    }
    result.digits[0] = _get_dec_digit(dec, MAX_BIN_DIGITS - i);
    // Берём следующую цифру в разряд 0/1
  }

  return result;
}

int _bcd_to_int(s21_bcd bcd) {
  int result = 0;
  N(bcd);
  return result;
}
