/// Сдвинуть bcd на один байт влево
void shift_bcd(s21_bcd *src) {
  src->bits[2] =
      (src->bits[2] << 1) | ((src->bits[1] >> (BLOCK_SIZE - 1)) & 0x1);
  src->bits[1] =
      (src->bits[1] << 1) | ((src->bits[0] >> (BLOCK_SIZE - 1)) & 0x1);
  src->bits[0] = (src->bits[0] << 1);
}

/// Получить псевдоцифру на k-м месте в bcd-записи
int get_kth_pseudodigit_from_bcd(s21_bcd *src, int k) {
  int result = -1;
  int block = (k - 1) * BCD_DIGIT_SIZE / BLOCK_SIZE;
  int part = ((k - 1) * BCD_DIGIT_SIZE % BLOCK_SIZE) / BCD_DIGIT_SIZE;
  result = ((src->bits[block] & (BCD_DIGIT_MAP << (part * BCD_DIGIT_SIZE))) >>
            (part * BCD_DIGIT_SIZE)) &
           BCD_DIGIT_MAP;
  return result;
}

/// Добавить 3 к k-му «знакоместу» в bcd-записи
void add_three_to_bcd_digit(s21_bcd *src, int k) {
  int block = (k - 1) * BCD_DIGIT_SIZE / BLOCK_SIZE;
  int part = ((k - 1) * BCD_DIGIT_SIZE % BLOCK_SIZE) / BCD_DIGIT_SIZE;
  src->bits[block] += (0x3 << (part * BCD_DIGIT_SIZE));
}

/// Нормализовать цифру на k-м месте в bcd-записи
void normalize_kth_digit(s21_bcd *src, int k) {
  int d = get_kth_pseudodigit_from_bcd(src, k);
  if (d > 4) {
    add_three_to_bcd_digit(src, k);
  }
}

/// Нормализовать bcd-запись
void normalize_bcd(s21_bcd *src) {
  for (int i = 1; i <= BIN_DIGITS / BCD_DIGIT_SIZE; i++) {
    normalize_kth_digit(src, i);
  }
}

/// Преобразовать decimal в bcd
void decimal_to_bcd(s21_decimal *src, s21_bcd *trgt) {}

/// Получить строку бинарного представления bcd-числа
void bcd_to_str(s21_bcd *src, char *trgt) {
  bin_to_str(src->bits[2], trgt);
  bin_to_str(src->bits[1], trgt + BLOCK_SIZE);
  bin_to_str(src->bits[0], trgt + 2 * BLOCK_SIZE);
}

/// Получить растянутую строку десятичного представления bcd-числа
void bcd_to_long_int_str(s21_bcd *src, char *trgt) {
  int d = BIN_DIGITS / BCD_DIGIT_SIZE;
  for (int i = d; i > 0; i--) {
    // TODO Заменить на цикл до BCD_DIGIT_SIZE
    int dc = (d - i) * BCD_DIGIT_SIZE;
    trgt[dc] = trgt[dc + 1] = trgt[dc + 2] = ' ';
    trgt[dc + 3] = (char)(get_kth_pseudodigit_from_bcd(src, i) + 48);
  }
  trgt[BIN_DIGITS] = '\0';
}

/// Преобразовать bcd в longint
void bcd_to_longint(s21_bcd *src, s21_longint *trgt) {
  int d = BIN_DIGITS / BCD_DIGIT_SIZE;
  for (int i = 1; i <= d; i++) {
    trgt->digits[BIN_DIGITS - i] = get_kth_pseudodigit_from_bcd(src, i);
  }
  for (int i = 0; i < BIN_DIGITS - d; i++) {
    trgt->digits[i] = 0;
  }
}

/// Преобразовать longint в строку
void longint_to_str(s21_longint *src, char *trgt) {
  for (int i = 0; i < BIN_DIGITS; i++) {
    trgt[i] = (char)(src->digits[i] + 48);
  }
  trgt[BIN_DIGITS] = '\0';
}

/// Точка входа
int main(void) {
  static char line[1024];

  FILE *f = fopen(PATH, "r");
  while (fgets(line, 1024, f) != NULL) {
    s21_decimal d = _line_parse(line);
    /*
    int num = 66;
    int td = get_kth_digit_from_decimal(&d, num);
    int tc = line[BLOCK_SIZE + BIN_DIGITS - num - 1] - 48;
    printf("%d: %d ~ %d == %d\n", num, tc, td, (tc == td));
    */

    s21_bcd b = {0};
    char bcd_str[BIN_DIGITS + 1];
    char bcd_int_str[BIN_DIGITS + 1];
    s21_longint l = {0};
    char bcd_longint_str[BIN_DIGITS + 1];

    for (int i = 1; i <= BIN_DIGITS; i++) {
      normalize_bcd(&b);
      bcd_to_str(&b, bcd_str);
      bcd_to_long_int_str(&b, bcd_int_str);
      // printf("%s\n", bcd_str);
      // printf("%s\n", bcd_int_str);

      shift_bcd(&b);
      b.bits[0] += get_kth_digit_from_decimal(&d, BIN_DIGITS - i);
      bcd_to_str(&b, bcd_str);
      bcd_to_long_int_str(&b, bcd_int_str);
      // printf("%s\n", bcd_str);
      // printf("%s\n", bcd_int_str);
    }

    bcd_to_longint(&b, &l);
    longint_to_str(&l, bcd_longint_str);
    printf("%s\n", bcd_str);
    printf("%s\n", bcd_int_str);
    printf("%s\n", bcd_longint_str);
    printf("%s\n\n", line + BLOCK_SIZE);
  }

  fclose(f);

  return 0;
}
