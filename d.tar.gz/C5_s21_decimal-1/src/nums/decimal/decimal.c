/**
 * @file decimal.c
 * @brief Работа с типом decimal (реализация)
 */

#include "decimal.h"

#include "internal.h"

/// Разобрать строку в decimal-запись
decimal decimal_from_str(char* s) {
  decimal result = {};
  if (strlen(s) < (BIT_Q + 1) * BIT_LEN) {
    exit(EXIT_FAILURE);
  }  // если строка короче минимальной длины

  for (int k = 0; k < BIT_Q + 1; k++) {
    result.bits[k] = byte_from_str(s + k * BYTE_LEN);
  }

  // TODO Добавить валидацию числа (нет ли единиц не в тех позициях)
  // TODO Решить, можно ли строке быть длинней, чем ожидаемое число

  return result;
}

/// Получить k-ю цифру из decimal
int decimal_digit(decimal d, int k) {
  int result = -1;
  if ((k < 1) || (k > DECIMAL_LEN)) {
    exit(EXIT_FAILURE);
  }  // нет такой цифры

  int block = (k - 1) / BIT_LEN;
  int position = (k - 1) % BIT_LEN;
  result = byte_bit(d.bits[block], position + 1);

  return result;
}

/// Превратить decimal в bcd
bcd decimal_to_bcd(decimal d) {
  bcd result = {};
  N(d);
  return result;
}

/// Получить строковое представление мантиссы
void decimal_to_str(char* s, decimal d) {
  if (s == NULL) {
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < BIT_Q; i++) {
    byte_to_str(s + BIT_LEN * i, d.bits[BIT_Q - i - 1]);
  }
}

/// Превратить decimal в simple-число
simple decimal_to_simple(decimal d) {
  simple result = {};
  N(d);
  return result;
}

/// Получить знак числа
int decimal_sign(decimal d) { return byte_sign(d.bits[BIT_Q]); }

/// Получить порядок (количество знаков после запятой) в десятичной системе
int decimal_order(decimal d) { return byte_order(d.bits[BIT_Q]); }

/// Сравнить два decimal-числа
/// TODO Использовать функцию из общего кода
int decimal_eq(decimal d, decimal dd) {
  int result = 1;
  for (int i = 0; i < BIT_Q; i++) {
    if (d.bits[i] != dd.bits[i]) {
      result = 0;
    }
  }
  return result;
}

/// Нормализовать ноль
void decimal_zero_normalize(decimal* d) {
  // TODO Сбросить порядок
  // TODO Унифицировать знак (+/-)
  // TODO Превратить «все единицы» во «все нули»
  N(d);
}
