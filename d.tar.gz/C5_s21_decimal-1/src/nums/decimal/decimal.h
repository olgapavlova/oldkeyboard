/**
 * @file decimal.h
 * @brief Работа с типами decimal и _decimal (декларации)
 */

#ifndef DECIMAL_H
#define DECIMAL_H

#include "constant.h"
#include "types.h"

/// @struct Полный синоним публичной структуры s21_decimal
struct decimal {
  bool valid;  //!< Флаг корректности данных в конкретной структуре
  int bits[BIT_Q +
           1];  //!< 3 байта на содержательную часть + 1 байт знака и порядка
};

/// Разобрать строку в decimal-запись
decimal decimal_from_str(char *);

/// Получить k-ю цифру из decimal
int decimal_digit(decimal, int);

/// Превратить decimal в bcd
bcd decimal_to_bcd(decimal);

/// Получить строковое представление бинарной части
void decimal_to_str(char *, decimal);

/// Превратить decimal в simple-число
simple decimal_to_simple(decimal);

/// Получить знак числа
int decimal_sign(decimal);

/// Получить порядок (количество знаков после запятой) в десятичной системе
int decimal_order(decimal);

/// Сравнить два decimal-числа
int decimal_eq(decimal, decimal);

/// Нормализовать знак нуля
/// TODO Добавить всюду в конвертирующих функциях
void decimal_zero_normalize(decimal *);

#endif
