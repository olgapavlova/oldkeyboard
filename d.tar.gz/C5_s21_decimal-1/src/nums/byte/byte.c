/**
 * @file byte.c
 * @brief Работа с типом byte (реализация)
 */

#include "byte.h"

#include "internal.h"

/// Разобрать начало строки в byte
byte byte_from_str(char* s) {
  byte result = 0;

  if (strlen(s) < BYTE_LEN) {
    exit(EXIT_FAILURE);
  }  // если строка короче минимальной длины

  for (int i = 0; i < BYTE_LEN; i++) {
    result <<= 1;
    result += (s[i] == '1');  // всё, что не 1, считаем как 0
  }

  return result;
}

/// Получить k-й бит из byte
int byte_bit(byte b, int k) {
  int result;
  if ((k < 1) || (k > BYTE_LEN)) {
    exit(EXIT_FAILURE);
  }  // нет такого бита
  result = ((b & (1 << (k - 1))) >> (k - 1)) & FIRST_DIGIT_MAP;
  return result;
}

/// Получить строковое представление byte
void byte_to_str(char* s, byte b) {
  for (int i = 0; i < BYTE_LEN; i++) {
    s[i] = ((b >> (BYTE_LEN - i - 1)) & FIRST_DIGIT_MAP) ? '1' : '0';
  }
  s[BYTE_LEN] = '\0';
}

/// Получить знак числа (из SO-байта)
int byte_sign(byte b) {
  int result = 0;
  result = (((b >> (BYTE_LEN - 1)) & FIRST_DIGIT_MAP) == 1) ? -1 : 1;
  return result;
}

/// Получить порядок (количество знаков после запятой) в десятичной системе (из
/// SO-байта)
int byte_order(byte b) {
  int result = (b >> ORDER_SHIFT) & ORDER_MAP;
  return result;
}

/// Проверить, описывает ли байт знак и порядок (т.е. является SO-байтом)
int byte_is_so(byte b) {
  int result = 0;
  if ((byte_order(b) > 28) || (byte_order(b) < 0)) {
    result -= 1;
  }
  if (b & EMPTY_SO_MAP) {
    result -= 2;
  }
  if (result == 0) {
    result = 1;
  }
  return result;
}

/// Нормализовать SO-байт (только заполненность битов)
void byte_normalize_so(byte* b) { *b &= (0xFFFFFFFF ^ EMPTY_SO_MAP); }
