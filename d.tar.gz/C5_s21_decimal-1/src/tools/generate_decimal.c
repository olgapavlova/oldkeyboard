/**
 * @file generate_decimal.c
 * @brief Генератор случайных decimal-данных
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define BIN_DIGITS 96
#define DEFAULT_LENGTH 10

// Знак и степень
void _print_random_meta(void) {
  printf("%d", rand() % 2);         // 31     знак
  printf("00000000");               // 24-30  не используется
  for (int i = 16; i <= 23; i++) {  // 16-23  показатель степени
    printf("%d", rand() % 2);
  }
  printf("000000000000000");  // 0-15   не используется
}

/// Мантисса
void _print_random_bin(void) {
  for (int i = 0; i < BIN_DIGITS; i++) {
    printf("%d", rand() % 2);
  }
}

/// Точка входа
int main(int argc, char **argv) {
  // Сколько строк генерить
  int length = (argc > 1) ? atoi(argv[1]) : DEFAULT_LENGTH;

  // Генератор
  srand(time(NULL));
  for (int i = 0; i < length; i++) {
    _print_random_meta();
    _print_random_bin();
    printf("\n");
  }
}
