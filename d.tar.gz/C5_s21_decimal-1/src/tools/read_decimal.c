/**
 * @file read_decimal.c
 * @brief Читает decimal из файла. Нужно для тестирования генератора.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../s21_decimal.h"

#define PATH "../data/random_decimal.txt"

/// Разобрать строку в decimal-запись
s21_decimal _line_parse(char *line) {
  s21_decimal result = {0};
  for (int k = 0; k < 4; k++) {
    for (int i = 32 * k; i < 32 * (k + 1); i++) {
      result.bits[3 - k] = (line[i] == '1') + (result.bits[3 - k] << 1);
    }
  }

  return result;
}

/// Точка входа
int main(void) {
  char line[1024];

  FILE *f = fopen(PATH, "r");
  while (fgets(line, 1024, f) != NULL) {
    s21_decimal d = _line_parse(line);
    printf("%s[%d]\n%d\n%d\n%d\n\n", line, d.bits[3], d.bits[2], d.bits[1],
           d.bits[0]);
  }

  fclose(f);

  return 0;
}
