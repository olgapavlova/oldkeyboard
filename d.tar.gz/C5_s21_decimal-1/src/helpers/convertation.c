#include "helpers.h"
#define PLUS_MASK 0xFFFFFFFF

/**
 * @brief функция переводит децимал с матриссой в 3 байта в длинный децимал с
 * мантиссой в 6 байт, нормализуя его в зависимости от переданной степени
 * @param source исходный децимал
 * @param destination указатель на длинный децимал
 * @param scale_max передаваемый из старшей функции показатель степени - большей
 * из степеней обрабатываемых числе
 */
void _convert_to_long_decimal(s21_decimal source, long_decimal *destination,
                              int scale_max) {
  for (int i = 0; i < 7; i++) {
    destination->bits_of_long[i] = 0;
  }
  destination->sign = _get_sign(source);
  destination->scale = scale_max;
  int source_scale = _get_scale(source);
  int scale_difference = scale_max - source_scale;

  destination->bits_of_long[0] = source.bits[0];
  destination->bits_of_long[1] = source.bits[1];
  destination->bits_of_long[2] = source.bits[2];

  for (int i = 0; i < scale_difference; i++) {
    _mul_by_ten(*destination, destination);
  }
}

/**
 * @brief функция перевода из длинного в стандартный децимал
 * @param source длинный исходный децимал
 * @param destination указатель на целевой децимал-результат
 * @param flag передаваемый сверху флаг валидного нуля, не дает счесть маленькое
 * чило ошибкой
 * @return код ошибки, 0 - ок, 1 - слишком большое, 2 - слишком маленькое
 * @note в случае, если переводимое число (до 192 бит) не вмещается в целевой
 * децимал (92 бита), мы производим деление мантиссы с потерей точности,
 * применяем банковское округление
 */
int _convert_from_long_decimal(long_decimal source, s21_decimal *destination,
                               int flag) {
  int error = 0;
  for (int i = 0; i < 4; i++) {
    destination->bits[i] = 0;
  }
  long_decimal rounding_result = source;
  _rounding(source, &rounding_result, &error);
  if (error) {
    return error;
  }
  destination->bits[0] = rounding_result.bits_of_long[0];
  destination->bits[1] = rounding_result.bits_of_long[1];
  destination->bits[2] = rounding_result.bits_of_long[2];
  _set_scale(destination, rounding_result.scale);
  _set_sign(destination, rounding_result.sign);
  if (destination->bits[0] == 0 && destination->bits[1] == 0 &&
      destination->bits[2] == 0 && !flag) {
    error = 2;
  }

  return error;
}

/**
 * @brief функция округляет длинный децимал до его вписывания в формат децимала
 * @param source длинный исходный децимал
 * @param rounding_result длинный децимал-результат
 * @param error код ошибки
 */
void _rounding(long_decimal source, long_decimal *rounding_result, int *error) {
  long_decimal no_overflow_copy = source;
  int to_round_up = 0;
  unsigned long long reminder = 0;
  unsigned long long reminder_sum = 0;
  unsigned long long no_overflow_reminder = 0;

  while ((source.bits_of_long[3] || source.bits_of_long[4] ||
          source.bits_of_long[5] || source.bits_of_long[6]) ||
         (source.scale > 28)) {
    if (((source.bits_of_long[3] != 0) || (source.bits_of_long[4] != 0) ||
         (source.bits_of_long[5] != 0) || (source.bits_of_long[6] != 0)) &&
        (source.scale <= 0)) {
      *error = (source.sign) ? 2 : 1;
      return;
    }
    reminder = 0;
    for (int i = 6; i >= 0; i--) {
      unsigned long long temporary =
          ((unsigned long long)reminder << 32) + source.bits_of_long[i];
      source.bits_of_long[i] = temporary / 10;
      reminder = temporary % 10;
    }
    reminder_sum += reminder;

    no_overflow_reminder = 0;
    for (int i = 6; i >= 0; i--) {
      unsigned long long temporary =
          ((unsigned long long)no_overflow_reminder << 32) +
          no_overflow_copy.bits_of_long[i];
      no_overflow_copy.bits_of_long[i] = temporary / 10;
      no_overflow_reminder = temporary % 10;
    }

    _rounding_definition(reminder, no_overflow_reminder, reminder_sum, source,
                         &to_round_up);
    if (to_round_up) {
      int carry = 1;
      for (int i = 0; i < 7 && carry; i++) {
        unsigned long long temporary_bank =
            (unsigned long long)source.bits_of_long[i] + carry;
        source.bits_of_long[i] = temporary_bank & PLUS_MASK;
        carry = temporary_bank >> 32;
      }
    }
    source.scale--;
  }
  *rounding_result = source;
}

/**
 * @brief функция определяет, стоит ли добавлять единицу в следующий разряд при
 * округлении
 * @param reminder остаток от деления
 * @param no_overflow_reminder остаток, очищенный от увеличения разряда
 * @param reminder_sum сумма всех остатков
 * @param source передаваемый для определения четности децимал
 * @param to_round_up указатель на решение об округлении
 */
void _rounding_definition(int reminder, int no_overflow_reminder,
                          int reminder_sum, long_decimal source,
                          int *to_round_up) {
  int rounding_condition_a = 0;
  int rounding_condition_b = 0;
  int rounding_condition_c = 0;
  int rounding_condition_d = 0;
  rounding_condition_a = (reminder > 5);
  rounding_condition_b = ((reminder == 5) && (no_overflow_reminder >= 5));
  rounding_condition_c = (reminder == reminder_sum);
  rounding_condition_d = (source.bits_of_long[0] & 1);
  *to_round_up =
      ((rounding_condition_a) ||
       (rounding_condition_b && !rounding_condition_c) ||
       (rounding_condition_b && rounding_condition_c && rounding_condition_d));
}