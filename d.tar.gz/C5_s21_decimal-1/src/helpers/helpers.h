#ifndef HELPERS_H
#define HELPERS_H

#include <stdio.h>

#include "s21_decimal.h"
#include "types.h"

int _get_sign(s21_decimal value);
void _set_sign(s21_decimal *value, int sign);

int _get_scale(s21_decimal value);
void _set_scale(s21_decimal *value, int scale);

void _compare_values(s21_decimal value_1, s21_decimal value_2, int *is_greater,
                     int *is_equal);
int _compare_abs_value(long_decimal long_value_1, long_decimal long_value_2);
int _mul_by_ten(long_decimal value, long_decimal *result);

void _basic_add(long_decimal long_value_1, long_decimal long_value_2,
                long_decimal *long_result);
void _basic_sub(long_decimal big_one, long_decimal small_one,
                long_decimal *long_result);
void _basic_mul(long_decimal long_value_1, long_decimal long_value_2,
                long_decimal *long_result);
void _basic_div(long_decimal long_value_1, long_decimal long_value_2,
                long_decimal *long_result);
void _whole_part_handle(long_decimal *remainder, long_decimal *temporary_result,
                        long_decimal *long_value_2);

void _long_decimal_add(long_decimal long_value_1, long_decimal long_value_2,
                       long_decimal *long_result);
void _long_decimal_sub(long_decimal long_value_1, long_decimal long_value_2,
                       long_decimal *long_result);
void _long_decimal_mul(long_decimal long_value_1, long_decimal long_value_2,
                       long_decimal *long_result);
void _long_decimal_div(long_decimal long_value_1, long_decimal long_value_2,
                       long_decimal *long_result);

void _convert_to_long_decimal(s21_decimal source, long_decimal *destination,
                              int scale_max);
int _convert_from_long_decimal(long_decimal source, s21_decimal *destination,
                               int flag);
void _rounding(long_decimal sourse, long_decimal *result, int *error);
void _rounding_definition(int reminder, int no_overflow_reminder,
                          int reminder_sum, long_decimal source,
                          int *to_round_up);

// временные функции для вывода чисел в разных представлениях, нужны для отладки
void _print_single_int_in_binary(int single_int);
void _print_decimal_in_binary(s21_decimal number);
void _print_long_decimal_in_binary(long_decimal number);
void _print_decimal_in_decimal(s21_decimal number);

#endif
