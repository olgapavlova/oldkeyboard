#include "helpers.h"

/**
 * @brief получаем знак числа типа s21_decimal.
 *
 * @param value передаваемое число типа s21_decimal.
 * @return 0 если число положительное, 1 - если отрицательное.
 */
int _get_sign(s21_decimal value) { return (value.bits[3] >> 31) & 1; }

/**
 * @brief устанавливаем знак для числа типа s21_decimal.
 *
 * @param value указатель на число типа s21_decimal.
 * @param sign устанавливаемый знак, 0 - число положительное, 1 - отрицательное.
 */
void _set_sign(s21_decimal *value, int sign) {
  if (sign) {
    value->bits[3] |= (1U << 31);
  } else {
    value->bits[3] &= ~(1U << 31);
  }
}
