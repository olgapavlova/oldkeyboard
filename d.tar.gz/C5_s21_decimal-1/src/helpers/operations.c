#include "helpers.h"
// маска для выделения конкретного слова
#define PLUS_MASK 0xFFFFFFFF
// число для сдвига по словам
#define TRANSFER_MARK 0x100000000LL
#define SCALE_DIV_LIMIT 30

/**
 * @brief базовая часть, выполняющая непосредственно деление длинных децималов
 * @param long_value_1 первый длинный децимал-делимое
 * @param long_value_2 второй длинный децимал-делитель
 * @param long_result указатель на длинный децимал-результат
 * @note выполняем деление за счет подсчета количества возможных вычитаний из
 * делимого подогнанного под ближайшую степень 10 делителя
 */
void _basic_div(long_decimal long_value_1, long_decimal long_value_2,
                long_decimal *long_result) {
  long_decimal remainder = {0};
  for (int i = 0; i < 7; i++) {
    long_result->bits_of_long[i] = 0;
    remainder.bits_of_long[i] = long_value_1.bits_of_long[i];
  }
  long_decimal temporary_result = {0};

  _whole_part_handle(&remainder, &temporary_result, &long_value_2);

  int power_of_minus_ten = 0;
  int scale_counter = 0;
  while (power_of_minus_ten < SCALE_DIV_LIMIT &&
         scale_counter < SCALE_DIV_LIMIT) {
    if (remainder.bits_of_long[0] == 0 && remainder.bits_of_long[1] == 0 &&
        remainder.bits_of_long[2] == 0 && remainder.bits_of_long[3] == 0 &&
        remainder.bits_of_long[4] == 0 && remainder.bits_of_long[5] == 0 &&
        remainder.bits_of_long[6]) {
      break;
    }
    while (_compare_abs_value(remainder, long_value_2) < 0 &&
           power_of_minus_ten < SCALE_DIV_LIMIT) {
      _mul_by_ten(remainder, &remainder);
      power_of_minus_ten++;
    }
    if (power_of_minus_ten < SCALE_DIV_LIMIT) {
      int sub_counter_after_dot = 0;
      while (_compare_abs_value(remainder, long_value_2) >= 0) {
        _basic_sub(remainder, long_value_2, &remainder);
        sub_counter_after_dot++;
      }
      for (int i = 0; i < power_of_minus_ten; i++) {
        _mul_by_ten(temporary_result, &temporary_result);
        scale_counter++;
      }
      long_decimal sub_counter_after_dot_decimal = {0};
      sub_counter_after_dot_decimal.bits_of_long[0] = sub_counter_after_dot;
      _basic_add(temporary_result, sub_counter_after_dot_decimal,
                 &temporary_result);
      power_of_minus_ten = 0;
    }
  }
  *long_result = temporary_result;
  long_result->scale = scale_counter;
}

/**
 * @brief деление целой части числа
 * @param remainder остаток числа
 * @param temporary_result передаваемый сверху длинный децимал для временной
 * записи результата
 * @param long_value_2 делитель
 */
void _whole_part_handle(long_decimal *remainder, long_decimal *temporary_result,
                        long_decimal *long_value_2) {
  long_decimal temporary_devisor = *long_value_2;
  while (_compare_abs_value(*remainder, *long_value_2) >= 0) {
    long_decimal previous_devisor = temporary_devisor;
    int power_of_ten = 0;
    while (_compare_abs_value(*remainder, temporary_devisor) >= 0) {
      previous_devisor = temporary_devisor;
      if (_mul_by_ten(temporary_devisor, &temporary_devisor)) {
        break;
      }
      power_of_ten++;
    }
    temporary_devisor = previous_devisor;
    power_of_ten--;
    int sub_counter = 0;
    while (_compare_abs_value(*remainder, temporary_devisor) >= 0) {
      _basic_sub(*remainder, temporary_devisor, remainder);
      sub_counter++;
    }
    long_decimal sub_counter_decimal = {0};
    sub_counter_decimal.bits_of_long[0] = sub_counter;
    for (int i = 0; i < power_of_ten; i++) {
      _mul_by_ten(sub_counter_decimal, &sub_counter_decimal);
    }
    _basic_add(*temporary_result, sub_counter_decimal, temporary_result);
    temporary_devisor = *long_value_2;
  }
}

/**
 * @brief базовая часть, выполняющая непосредственно умножение длинных децималов
 * @param long_value_1 первый длинный децимал-множитель
 * @param long_value_2 второй длинный децимал-множитель
 * @param long_result указатель на длинный децимал-результат
 */
void _basic_mul(long_decimal long_value_1, long_decimal long_value_2,
                long_decimal *long_result) {
  for (int i = 0; i < 7; i++) {
    long_result->bits_of_long[i] = 0;
  }
  for (int i = 0; i < 7; i++) {
    unsigned long long carry = 0;
    int j;
    for (j = 0; j < 7 && i + j < 7; j++) {
      unsigned long long temp =
          (unsigned long long)long_value_1.bits_of_long[i] *
              (unsigned long long)long_value_2.bits_of_long[j] +
          (unsigned long long)long_result->bits_of_long[i + j] + carry;
      long_result->bits_of_long[i + j] = temp & PLUS_MASK;
      carry = temp >> 32;
    }
    for (int k = i + j; k < 7 && carry; k++) {
      unsigned long long temp =
          (unsigned long long)long_result->bits_of_long[k] + carry;
      long_result->bits_of_long[k] = temp & PLUS_MASK;
      carry = temp >> 32;
    }
  }
}

/**
 * @brief базовая часть, выполняющая непосредственно сложение длинных децималов
 * @param long_value_1 первый суммируемый длинный децимал
 * @param long_value_2 второй суммируемый длинный децимал
 * @param long_result указатель на длинный децимал-результат
 */
void _basic_add(long_decimal long_value_1, long_decimal long_value_2,
                long_decimal *long_result) {
  int carry = 0;
  for (int i = 0; i < 7; i++) {
    long long temporary = (long long)long_value_1.bits_of_long[i] +
                          (long long)long_value_2.bits_of_long[i] + carry;
    long_result->bits_of_long[i] = (temporary & PLUS_MASK);
    carry = (temporary >> 32);
  }
}

/**
 * @brief базовая часть, выполняющая непосредственно вычитание длинных децималов
 * (всегда меньший из большего)
 * @param big_one первый длинный децимал - уменьшаемое
 * @param small_one второй длинный децимал - вычитаемое
 * @param long_result указатель на длинный децимал-результат
 */
void _basic_sub(long_decimal big_one, long_decimal small_one,
                long_decimal *long_result) {
  int carry = 0;
  for (int i = 0; i < 7; i++) {
    long long temporary_sub =
        (long long)big_one.bits_of_long[i] - small_one.bits_of_long[i] - carry;
    if (temporary_sub < 0) {
      temporary_sub += TRANSFER_MARK;
      carry = 1;
    } else {
      carry = 0;
    }
    long_result->bits_of_long[i] = temporary_sub & PLUS_MASK;
  }
}

/**
 * @brief функция осуществляет деление двух чисел формата long_decimal
 * @param long_value_1 длинный децимал-делимое
 * @param long_value_2 длинный децимал-делитель
 * @param long_result указатель на длинный децимал-результат
 * @note
 */
void _long_decimal_div(long_decimal long_value_1, long_decimal long_value_2,
                       long_decimal *long_result) {
  for (int i = 0; i < 7; i++) {
    long_result->bits_of_long[i] = 0;
  }
  _basic_div(long_value_1, long_value_2, long_result);
  long_result->sign = (long_value_1.sign != long_value_2.sign);
}

/**
 * @brief функция умножает два числа типа long_decimal
 * @param long_value_1 первый длинный децимал-множитель
 * @param long_value_2 второй длинный децимал-множитель
 * @param long_result указатель на длинный децимал-результат
 * @note определяем знак и производим умножение
 */
void _long_decimal_mul(long_decimal long_value_1, long_decimal long_value_2,
                       long_decimal *long_result) {
  for (int i = 0; i < 7; i++) {
    long_result->bits_of_long[i] = 0;
  }
  long_result->scale = long_value_1.scale;
  if (long_value_1.sign == long_value_2.sign) {
    long_result->sign = 0;
  } else {
    long_result->sign = 1;
  }
  _basic_mul(long_value_1, long_value_2, long_result);
}

/**
 * @brief функция суммирует два значения типа long_decimal
 * @param long_value_1 первый суммируемый длинный децимал
 * @param long_value_2 второй суммируемый длинный децимал
 * @param long_result указатель на длинный децимал-результат
 * @note учитываем знак и производим либо сложение, либо вычитание
 */
void _long_decimal_add(long_decimal long_value_1, long_decimal long_value_2,
                       long_decimal *long_result) {
  for (int i = 0; i < 7; i++) {
    long_result->bits_of_long[i] = 0;
  }
  long_result->scale = long_value_1.scale;

  if (long_value_1.sign == long_value_2.sign) {
    _basic_add(long_value_1, long_value_2, long_result);
    long_result->sign = long_value_1.sign;
  } else {
    int which_is_grater = 0;
    for (int i = 6; i >= 0; i--) {
      if (long_value_1.bits_of_long[i] > long_value_2.bits_of_long[i]) {
        which_is_grater = 1;
        break;
      }
      if (long_value_1.bits_of_long[i] < long_value_2.bits_of_long[i]) {
        which_is_grater = -1;
        break;
      }
    }
    if (which_is_grater > 0) {
      _basic_sub(long_value_1, long_value_2, long_result);
      long_result->sign = long_value_1.sign;
    } else if (which_is_grater < 0) {
      _basic_sub(long_value_2, long_value_1, long_result);
      long_result->sign = long_value_2.sign;
    } else {
      long_result->sign = 0;
    }
  }
}

/**
 * @brief функция вычитает значение типа long_decimal из другого значения того
 * же типа
 * @param long_value_1 первый длинный децимал - уменьшаемое
 * @param long_value_2 второй длинный децимал - вычитаемое
 * @param long_result указатель на длинный децимал-результат
 * @note учитываем знак и производим либо вычитание, либо сложение
 */
void _long_decimal_sub(long_decimal long_value_1, long_decimal long_value_2,
                       long_decimal *long_result) {
  for (int i = 0; i < 7; i++) {
    long_result->bits_of_long[i] = 0;
  }
  long_result->scale = long_value_1.scale;

  if (long_value_1.sign != long_value_2.sign) {
    _basic_add(long_value_1, long_value_2, long_result);
    long_result->sign = long_value_1.sign;
  } else {
    int which_is_grater = 0;
    for (int i = 6; i >= 0; i--) {
      if (long_value_1.bits_of_long[i] > long_value_2.bits_of_long[i]) {
        which_is_grater = 1;
        break;
      }
      if (long_value_1.bits_of_long[i] < long_value_2.bits_of_long[i]) {
        which_is_grater = -1;
        break;
      }
    }
    if (which_is_grater > 0) {
      _basic_sub(long_value_1, long_value_2, long_result);
      long_result->sign = long_value_1.sign;
    } else if (which_is_grater < 0) {
      _basic_sub(long_value_2, long_value_1, long_result);
      if (long_value_1.sign == 1) {
        long_result->sign = 0;
      } else {
        long_result->sign = 1;
      }
    } else {
      long_result->sign = 0;
    }
  }
}

/**
 * @brief функция сравнения модулей числе
 * @param long_value_1 первое сравниваемое число
 * @param long_value_2 второе сравниваемое число
 * @note оперируем числами, уже нормализованными по scale
 */
int _compare_abs_value(long_decimal long_value_1, long_decimal long_value_2) {
  for (int i = 6; i >= 0; i--) {
    if (long_value_1.bits_of_long[i] > long_value_2.bits_of_long[i]) {
      return 1;
    }
    if (long_value_1.bits_of_long[i] < long_value_2.bits_of_long[i]) {
      return -1;
    }
  }
  return 0;
}

/**
 * @brief функция умножения длинного децимала на 10
 * @param value исходное значение
 * @param result указатель на результирующее значение
 */
int _mul_by_ten(long_decimal value, long_decimal *result) {
  int carry = 0;
  for (int j = 0; j < 7; j++) {
    unsigned long long temporary =
        (unsigned long long)value.bits_of_long[j] * 10 + carry;
    result->bits_of_long[j] = temporary & PLUS_MASK;
    carry = temporary >> 32;
  }

  return carry;
}

void _compare_values(s21_decimal value_1, s21_decimal value_2, int *is_greater,
                     int *is_equal) {
  int sign_1 = _get_sign(value_1);
  int sign_2 = _get_sign(value_2);
  int scale_1 = _get_scale(value_1);
  int scale_2 = _get_scale(value_2);
  int scale_max = (scale_1 > scale_2) ? scale_1 : scale_2;
  long_decimal long_value_1 = {0};
  long_decimal long_value_2 = {0};
  _convert_to_long_decimal(value_1, &long_value_1, scale_max);
  _convert_to_long_decimal(value_2, &long_value_2, scale_max);
  int max_abs = _compare_abs_value(long_value_1, long_value_2);
  if ((max_abs == 0) && (sign_1 == sign_2)) {
    *is_equal = 1;
  }
  if (sign_1 != sign_2) {
    *is_greater = (sign_1 < sign_2);
  } else {
    if (sign_1 == 1) {
      *is_greater = (max_abs < 0);
    } else if (sign_1 == 0) {
      *is_greater = (max_abs > 0);
    }
  }
}
