#include "helpers.h"

/**
 * @brief получаем масштаб числа типа s21_decimal.
 *
 * @param value передаваемое число типа s21_decimal.
 * @return значение масштаба от 0 до 28.
 */
int _get_scale(s21_decimal value) { return (value.bits[3] >> 16) & 0xFF; }

/**
 * @brief очишаем имеющийся и устанавливаем новый масштаб числа типа
 * s21_decimal.
 *
 * @param value указатель на число типа s21_decimal.
 * @param scale устанавливаемое значение масштаба от 0 до 28.
 */
void _set_scale(s21_decimal *value, int scale) {
  value->bits[3] &= ~(0xFF << 16);
  value->bits[3] |= (scale & 0xFF) << 16;
}