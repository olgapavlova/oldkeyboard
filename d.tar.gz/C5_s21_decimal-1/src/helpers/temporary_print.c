#include "helpers.h"
#define UINT_MAX 4294967296

/**
 * @brief временная функция для вывода одного слова в двоичном представлении в
 * консоль
 * @param single_int передаваемый байт децимала
 */
void _print_single_int_in_binary(int single_int) {
  for (int i = 31; i >= 0; i--) {
    printf("%d", (single_int >> i & 1));
    // if (i % 8 == 0) {
    // printf(" ");
    //}
  }
}

/**
 * @brief временная функция для вывода всего децимала в двоичном представлении в
 * консоль
 * @param number передаваемый децимал
 */
void _print_decimal_in_binary(s21_decimal number) {
  for (int i = 3; i >= 0; i--) {
    printf("bits[%d]: ", i);
    _print_single_int_in_binary(number.bits[i]);
    printf("\n");
  }
}

/**
 * @brief временная функция для вывода всего длинного децимала в двоичном
 * представлении в консоль
 * @param number передаваемый длинный децимал
 */
void _print_long_decimal_in_binary(long_decimal number) {
  for (int i = 6; i >= 0; i--) {
    _print_single_int_in_binary(number.bits_of_long[i]);
  }
  printf("\n");
}

/**
 * @brief временная функция для вывода всего децимала в десятичном представлении
 * в консоль
 * @param number передаваемый децимал
 * @note здесь мы используем недопустимый тип, но делаем это для отладки, в
 * итоговую библиотеку эти функции не пойдут
 */
void _print_decimal_in_decimal(s21_decimal number) {
  int sign = _get_sign(number);
  if (sign) {
    printf("-");
  }
  __uint128_t mantissa = (unsigned int)number.bits[0];
  __uint128_t mantissa1 = 0;
  mantissa1 = (unsigned int)number.bits[1];
  mantissa = mantissa + (mantissa1 * UINT_MAX);
  __uint128_t mantissa2 = 0;
  mantissa2 = (unsigned int)number.bits[2];
  mantissa = mantissa + (mantissa2 * UINT_MAX * UINT_MAX);

  char digits[40];
  int index = 0;
  while (mantissa > 0) {
    digits[index++] = '0' + (mantissa % 10);
    mantissa /= 10;
  }

  for (int i = (index - 1); i >= 0; i--) {
    putchar(digits[i]);
    if (i % 3 == 0) {
      printf(" ");
    }
  }
  printf("\n");
  int scale = _get_scale(number);
  printf("scale = %d \n", scale);
}