#include "functions.h"

/**
 * @brief функция сравнения двух чисел типа s21_decimal, проверяет, является ли
 * первое число большим чем второе или равным ему
 * @param value_1 первый децимал
 * @param value_2 второй децимал
 * @return 1 - если value_1 больше или равно, 0 - если нет
 */
int s21_is_greater_or_equal(s21_decimal value_1, s21_decimal value_2) {
  int result = 0;
  int is_greater = 0, is_equal = 0;
  _compare_values(value_1, value_2, &is_greater, &is_equal);
  if (is_greater || is_equal) {
    result = 1;
  }

  if (DECIMALS_ZERO) {
    result = 1;
  }

  return result;
}
