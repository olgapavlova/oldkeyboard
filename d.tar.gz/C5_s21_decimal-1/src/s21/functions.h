#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <stdio.h>
#define DECIMALS_ZERO                                                      \
  (value_1.bits[0] == 0 && value_2.bits[0] == 0 && value_1.bits[1] == 0 && \
   value_2.bits[1] == 0 && value_1.bits[2] == 0 && value_2.bits[2] == 0)

#include "../helpers/helpers.h"

int s21_add(s21_decimal value_1, s21_decimal value_2, s21_decimal *result);
int s21_sub(s21_decimal value_1, s21_decimal value_2, s21_decimal *result);
int s21_mul(s21_decimal value_1, s21_decimal value_2, s21_decimal *result);
int s21_div(s21_decimal value_1, s21_decimal value_2, s21_decimal *result);

int s21_is_less(s21_decimal value_1, s21_decimal value_2);
int s21_is_less_or_equal(s21_decimal value_1, s21_decimal value_2);
int s21_is_greater(s21_decimal value_1, s21_decimal value_2);
int s21_is_greater_or_equal(s21_decimal value_1, s21_decimal value_2);
int s21_is_equal(s21_decimal value_1, s21_decimal value_2);
int s21_is_not_equal(s21_decimal value_1, s21_decimal value_2);

#endif
