/**
 * @file s21.h
 * @brief Внутренний заголовочный файл модуля с реализацией
 */

#ifndef S21_H
#define S21_H

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "constant.h"
#include "helpers.h"
#include "s21_decimal.h"
#include "types.h"

#endif
