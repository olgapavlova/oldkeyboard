#include "functions.h"

/**
 * @brief функция сложения двух чисел формата s21_decimal.
 * @param value_1 первое суумируемое значение
 * @param value_2 второе суммируемое значение
 * @param result указатель на s21_decimal-результат
 * @return возвращает ошибку, принимаемую из функции конвертации
 * @note принимаем два децимала - переводим их в большую структуру с
 * одновременной нормализацией по большей степени - складывваем две больших
 * структуры - возвращаем в s21_decimal
 */
int s21_add(s21_decimal value_1, s21_decimal value_2, s21_decimal *result) {
  int error = 0;
  int valid_zero_flag = 0;
  int scale_1 = _get_scale(value_1);
  int scale_2 = _get_scale(value_2);
  int scale_max = (scale_1 > scale_2) ? scale_1 : scale_2;

  long_decimal long_value_1 = {0};
  long_decimal long_value_2 = {0};
  _convert_to_long_decimal(value_1, &long_value_1, scale_max);
  _convert_to_long_decimal(value_2, &long_value_2, scale_max);

  long_decimal long_result = {0};
  _long_decimal_add(long_value_1, long_value_2, &long_result);

  int value1_sign = _get_sign(value_1);
  int value2_sign = _get_sign(value_2);
  if (_compare_abs_value(long_value_1, long_value_2) == 0 &&
      value1_sign != value2_sign) {
    valid_zero_flag = 1;
  }

  if (DECIMALS_ZERO) {
    valid_zero_flag = 1;
  }

  error = _convert_from_long_decimal(long_result, result, valid_zero_flag);

  return error;
}