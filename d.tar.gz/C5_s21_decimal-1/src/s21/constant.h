/**
 * @file constant.h
 * @brief Определения констант проекта
 */

#ifndef CONSTANT_H
#define CONSTANT_H

#define E_SUCCESS 0  // возвращаем код успеха
#define E_FAILURE 1  // возвращаем код ошибки

#define BIT_LEN 32  // длина блока бит (целого числа)
#define BIT_Q 3     // количество блоков

#define DECIMAL_LEN BIT_LEN* BIT_Q  // сколько цифр в двоичном числе
#define BCD_DIGIT_LEN 4  // сколько бит в бинарной записи BCD-цифры
#define BCD_LEN DECIMAL_LEN  // сколько цифр в BCD-числе (с избытком)

#define BCD_DIGIT_MAP 0xF    // маска цифры BCD-числа
#define FIRST_DIGIT_MAP 0x1  // маска первого бита
#define ORDER_SHIFT 0x10     // сдвиг кода порядка
#define ORDER_MAP 0x1F  // маска кода порядка после сдвига
#define EMPTY_SO_MAP \
  0xFF00FFFF  // маска запретных битов в блоке «знак+экспонента»

#endif
