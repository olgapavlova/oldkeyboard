/**
 * @file s21_decimal.h
 * @brief Типы данных и публичные функции модуля
 */

#ifndef S21_DECIMAL_H
#define S21_DECIMAL_H

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

/**
 * @struct Тип для хранения числа в десятичном представлении с сохранением
 * точности
 */
typedef struct _s21_decimal s21_decimal;

/**
 * @brief Арифметические операции
 */
int s21_add(s21_decimal, s21_decimal, s21_decimal *);
int s21_sub(s21_decimal, s21_decimal, s21_decimal *);
int s21_mul(s21_decimal, s21_decimal, s21_decimal *);
int s21_div(s21_decimal, s21_decimal, s21_decimal *);

/**
 * @brief Операции сравнения
 */
int s21_is_less(s21_decimal, s21_decimal);
int s21_is_less_or_equal(s21_decimal, s21_decimal);
int s21_is_greater(s21_decimal, s21_decimal);
int s21_is_greater_or_equal(s21_decimal, s21_decimal);
int s21_is_equal(s21_decimal, s21_decimal);
int s21_is_not_equal(s21_decimal, s21_decimal);

// Преобразователи
// Возвращаемое значение — код ошибки:
//  0 — OK
// 	1 — ошибка вычисления
int s21_from_int_to_decimal(int, s21_decimal *);
int s21_from_float_to_decimal(float, s21_decimal *);
int s21_from_decimal_to_int(s21_decimal, int *);
int s21_from_decimal_to_float(s21_decimal, float *);

// Другие функции
// Возвращаемое значение — код ошибки:
//  0 — OK
// 	1 — ошибка вычисления
int s21_floor(s21_decimal, s21_decimal *);
int s21_round(s21_decimal, s21_decimal *);
int s21_truncate(s21_decimal, s21_decimal *);
int s21_negate(s21_decimal, s21_decimal *);

#endif
